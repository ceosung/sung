module.exports = {
  BOT_TOKEN: "YOUR_TOKEN_BOT_API", // MASUKIN TOKEN BOT TELEGRAM KAMU
  OWNER_ID: ["6142885267"], // MASUKIN ID AKUN TELEGRAM KAMU
};

/*/  🔎  Project Information 
 *  ─────────────────────────────────────────
 *  ✈️ Telegram Developer: t.me/Vwyro
 *  📞 Official Channel : t.me/VerowAbout
 
  *  🔮 Thanks Too 
  - Xatanicall ( Support )
  - LumnzTyz ( Support )
  - Amelia ( Support )
 - RenXiter ( Support )
 
 *  © Base Telegram Bot by Verow
 
 *  Notes:
 *  - Jangan menghapus credit ini sebagai bentuk penghargaan terhadap pembuat asli.
 *  - Credit ini wajib dicantumkan dalam setiap pengembangan atau distribusi ulang.
 *  - Silakan modifikasi fitur dan logika bot, namun tetap hormati hak cipta pembuat.

 *  Terima kasih telah menggunakan base bot ini!
 /*/